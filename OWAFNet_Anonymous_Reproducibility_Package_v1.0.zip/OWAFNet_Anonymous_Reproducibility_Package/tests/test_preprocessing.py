from __future__ import annotations

import numpy as np

from owafnet.preprocessing import center_crop_or_symmetric_pad


def test_center_crop_is_deterministic():
    waveform = np.arange(10, dtype=np.float32)
    assert center_crop_or_symmetric_pad(waveform, 6).tolist() == [2, 3, 4, 5, 6, 7]


def test_symmetric_zero_padding():
    waveform = np.asarray([1, 2, 3], dtype=np.float32)
    assert center_crop_or_symmetric_pad(waveform, 8).tolist() == [0, 0, 1, 2, 3, 0, 0, 0]

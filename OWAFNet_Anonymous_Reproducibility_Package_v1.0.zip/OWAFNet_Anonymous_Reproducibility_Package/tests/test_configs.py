from __future__ import annotations

from owafnet.config import load_yaml


def test_primary_dataset_constants():
    pmemo = load_yaml("configs/datasets/pmemo.yaml")
    deam = load_yaml("configs/datasets/deam.yaml")
    assert pmemo["dataset"]["split_sizes"] == {"train": 556, "validation": 119, "test": 119}
    assert pmemo["audio"]["target_samples"] == 144000
    assert pmemo["spectrogram"]["output_frames"] == 281
    assert deam["dataset"]["split_sizes"] == {"train": 1262, "validation": 270, "test": 270}
    assert deam["audio"]["target_samples"] == 720000
    assert deam["audio"]["windows_per_item"] == 5


def test_search_grid_has_96_candidates():
    grid = load_yaml("configs/hyperparameter_grid.yaml")["local_models"]["grid"]
    count = len(grid["learning_rate"]) * len(grid["weight_decay"]) * len(grid["dropout"]) * len(grid["batch_size"])
    assert count == 96

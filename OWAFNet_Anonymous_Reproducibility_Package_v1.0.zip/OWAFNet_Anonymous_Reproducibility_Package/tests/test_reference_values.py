from __future__ import annotations

import json


def test_table_internal_averages():
    data = json.load(open("results/reference/expected_results.json", encoding="utf-8"))
    for section in ("pmemo_model_comparison", "deam_model_comparison"):
        for result in data[section].values():
            calculated = (result["arousal_f1"] + result["valence_f1"]) / 2
            assert abs(calculated - result["average_f1"]) <= 0.00005 + 1.0e-12


def test_reference_artifact_is_explicitly_marked():
    data = json.load(open("results/reference/expected_results.json", encoding="utf-8"))
    assert data["artifact_status"] == "manuscript_reference_values_not_fresh_execution"

from __future__ import annotations

import pandas as pd

from owafnet.metrics import multitask_metrics


def test_reference_fixture_reconstructs_primary_metrics():
    frame = pd.read_csv("results/reference/reference_predictions_seed42.csv")
    labels = frame[["y_arousal", "y_valence"]].to_numpy()
    probabilities = frame[["p_arousal", "p_valence"]].to_numpy()
    result = multitask_metrics(labels, probabilities)
    assert result["arousal"]["confusion"] == [[62, 12], [0, 45]]
    assert result["valence"]["confusion"] == [[49, 11], [2, 57]]
    assert round(result["arousal"]["support_weighted_f1"], 4) == 0.9006
    assert round(result["valence"]["support_weighted_f1"], 4) == 0.8902
    assert round(result["average_f1"], 4) == 0.8954
    assert round(result["arousal"]["brier"], 3) == 0.083
    assert round(result["valence"]["brier"], 3) == 0.096
    assert round(result["arousal"]["ece"], 3) == 0.037
    assert round(result["valence"]["ece"], 3) == 0.049

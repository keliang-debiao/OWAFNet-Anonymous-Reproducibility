from __future__ import annotations

import json

from owafnet.analysis import seed_summary


def test_owafnet_seed_summary():
    values = json.load(open("results/reference/expected_results.json", encoding="utf-8"))["seed_runs"]["owafnet"]
    result = seed_summary(values)
    assert round(result["mean"], 5) == 0.89520
    assert round(result["sample_sd"], 5) == 0.00091
    assert round(result["ci_low"], 5) == 0.89407
    assert round(result["ci_high"], 5) == 0.89633

from __future__ import annotations

import importlib.util
from pathlib import Path


def load_audit_module():
    path = Path("scripts/audit_parameters.py")
    spec = importlib.util.spec_from_file_location("audit_parameters", path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


def test_literal_parameter_formula_and_unresolved_difference():
    module = load_audit_module()
    components = module.documented_owafnet_count()
    assert components["total"] == 180294
    assert 680578 - components["total"] == 500284


def test_baseline_parameter_formulas_match_rounded_table_values():
    module = load_audit_module()
    counts = module.baseline_counts()
    assert round(counts["cnn"] / 1e6, 3) == 0.520
    assert round(counts["bilstm"] / 1e6, 3) == 0.751
    assert round(counts["transformer"] / 1e6, 3) == 2.378
    assert round(counts["resnet18"] / 1e6, 3) == 11.615

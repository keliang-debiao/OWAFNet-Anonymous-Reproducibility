# Output Schema

Each run directory contains:

- `resolved_config.json`: complete dataset and model configuration used by the run.
- `parameter_count.json`: implementation and manuscript parameter totals and their match status.
- `epochs.jsonl`: one genuine record per completed epoch.
- `best_checkpoint.pt`: model state selected only by validation average F1.
- `test_predictions.csv`: one row per independent song or excerpt with labels, probabilities, and hard predictions.
- `summary.json`: best epoch, validation score, test metrics, loss, seed, device, and software environment.

The prediction schema is:

```text
item_id,y_arousal,y_valence,p_arousal,p_valence,pred_arousal,pred_valence
```

For DEAM, each row is an excerpt-level result after averaging five window logits. Window-level predictions are not treated as independent test observations.

Reference-only files use an additional `artifact_status` field so automated checks can reject them if they are accidentally mixed with empirical run outputs.

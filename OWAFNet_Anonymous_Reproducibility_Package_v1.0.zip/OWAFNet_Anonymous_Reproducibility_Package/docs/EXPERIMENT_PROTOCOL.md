# Experiment Protocol

## Primary targets

Each item has normalized arousal and valence values. The two binary labels are defined independently as `1` only when the normalized rating is strictly greater than 0.5. Values equal to 0.5 belong to class 0. The model returns two logits and minimizes the sum of the two binary cross-entropy losses.

## PMEmo

- Use all 794 identifiers from the 2018 static-annotation release.
- Preserve the source annotation order, shuffle once with `numpy.random.default_rng(42)`, and assign 556/119/119 items to train/validation/test.
- Decode mono audio at 16 kHz and center-crop or symmetrically zero-pad to 144,000 samples.
- Extract a 128-bin Slaney-normalized power Mel spectrogram using FFT/window 2,048, hop 512, centered reflect padding, 0-8 kHz, per-clip maximum decibel reference, and an 80 dB range.
- Normalize as `(dB + 80) / 80`, clip to `[0, 1]`, and remove the final frame to obtain `1 x 128 x 281` float32 input.
- Construct five stochastic views per training item. Apply a circular frame shift in `[-28, 28]` with probability 0.5. Independently apply up to two time masks of width 28 and two frequency masks of width 16 with probability 0.5.
- Use one unaugmented input per validation or test item.

## DEAM

- Use all 1,802 released 45-second excerpts and whole-excerpt static ratings.
- Normalize ratings with `(rating - 1) / 8`, then create the binary targets at 0.5.
- Preserve source order, shuffle with generator seed 42, and assign 1,262/270/270 excerpts.
- Standardize each excerpt to 720,000 samples and divide it into five consecutive non-overlapping 144,000-sample windows.
- Each of the five training views independently selects one window before applying the PMEmo rolling and masking operators.
- At validation and test time, average the five window logits separately for each task and apply sigmoid only after averaging.

## Optimization

- Adam with beta values 0.9 and 0.999 and epsilon `1e-8`.
- Maximum 80 epochs.
- ReduceLROnPlateau on validation average F1, factor 0.5, patience 4, minimum learning rate `1e-6`.
- Early stopping after 12 epochs without an improvement greater than `1e-4`.
- Retain the checkpoint with the highest validation average F1; exact ties retain the earlier epoch.
- Execute seeds 42, 123, 456, 789, and 1000 on the same fixed partition.
- Never inspect test predictions during architecture, hyperparameter, checkpoint, or label-boundary selection.

## Metrics

Calculate class F1 separately for labels 0 and 1. Weight each class F1 by its support within that task to obtain task F1. Average the arousal and valence task F1 values to obtain average F1. Calculate all metrics once from item-level outputs. ECE uses 15 equal-width bins and the predicted high-class probability. Empty bins contribute zero. No post-hoc calibration is applied.

## Uncertainty

- Compute the arithmetic mean, sample standard deviation, and two-sided Student t interval across five initialization seeds on the fixed partition.
- For paired PMEmo comparisons, align seed-42 song-level predictions and draw 10,000 paired song-index bootstrap samples with generator seed 42. Recalculate support-weighted F1 within every resample.

## Timing

Use batch size one, evaluation mode, disabled gradients, 100 warm-up passes, and 1,000 timed passes. Synchronize CUDA before and after every GPU timing. Reset peak GPU memory statistics before measurement. CPU timing uses one thread. Timing covers model forward propagation only and excludes decoding and feature extraction.

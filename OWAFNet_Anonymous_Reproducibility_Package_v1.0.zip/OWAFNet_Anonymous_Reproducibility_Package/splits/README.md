# Frozen Splits

Generate the following files from the complete analysis manifests before archival:

- `pmemo_seed42.csv`: 556 train, 119 validation, and 119 test songs.
- `deam_seed42.csv`: 1,262 train, 270 validation, and 270 test excerpts.

Do not place windows or augmented views in different partitions. The CSV files produced by `scripts/make_splits.py` are item-level assignments and include a SHA-256 digest of the source manifest in the adjacent audit JSON.

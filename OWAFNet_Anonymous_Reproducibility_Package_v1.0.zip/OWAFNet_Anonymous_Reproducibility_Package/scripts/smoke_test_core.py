#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

from owafnet.analysis import seed_summary
from owafnet.config import load_yaml
from owafnet.metrics import multitask_metrics
from owafnet.preprocessing import center_crop_or_symmetric_pad


ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    frame = pd.read_csv(ROOT / "results/reference/reference_predictions_seed42.csv")
    metrics = multitask_metrics(frame[["y_arousal", "y_valence"]].to_numpy(), frame[["p_arousal", "p_valence"]].to_numpy())
    assert metrics["arousal"]["confusion"] == [[62, 12], [0, 45]]
    assert metrics["valence"]["confusion"] == [[49, 11], [2, 57]]
    assert round(metrics["average_f1"], 4) == 0.8954
    values = json.loads((ROOT / "results/reference/expected_results.json").read_text(encoding="utf-8"))["seed_runs"]["owafnet"]
    summary = seed_summary(values)
    assert round(summary["mean"], 5) == 0.89520
    assert center_crop_or_symmetric_pad(np.arange(10, dtype=np.float32), 6).tolist() == [2, 3, 4, 5, 6, 7]
    config = load_yaml(ROOT / "configs/datasets/pmemo.yaml")
    assert config["spectrogram"]["output_frames"] == 281
    print("Core smoke test passed without requiring PyTorch or audio data.")


if __name__ == "__main__":
    main()

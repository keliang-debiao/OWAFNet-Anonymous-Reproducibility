#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import statistics
import time
from pathlib import Path

import torch

from owafnet.config import deep_merge, load_yaml
from owafnet.models import build_model, count_trainable_parameters


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset-config", required=True)
    parser.add_argument("--model-config", required=True)
    parser.add_argument("--device", choices=["cpu", "cuda"], required=True)
    parser.add_argument("--warmup", type=int, default=100)
    parser.add_argument("--passes", type=int, default=1000)
    parser.add_argument("--output")
    args = parser.parse_args()
    if args.device == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but is unavailable")
    if args.device == "cpu":
        torch.set_num_threads(1)
    device = torch.device(args.device)
    config = deep_merge(load_yaml(args.dataset_config), load_yaml(args.model_config))
    model = build_model(config).to(device).eval()
    sample = torch.zeros((1, 1, 128, 281), dtype=torch.float32, device=device)
    with torch.no_grad():
        for _ in range(args.warmup):
            model(sample)
        if device.type == "cuda":
            torch.cuda.synchronize()
            torch.cuda.reset_peak_memory_stats()
        latencies = []
        for _ in range(args.passes):
            if device.type == "cuda":
                torch.cuda.synchronize()
            start = time.perf_counter_ns()
            model(sample)
            if device.type == "cuda":
                torch.cuda.synchronize()
            latencies.append((time.perf_counter_ns() - start) / 1_000_000)
    result = {
        "device": str(device),
        "device_name": torch.cuda.get_device_name(0) if device.type == "cuda" else "cpu_single_thread",
        "batch_size": 1,
        "warmup_passes": args.warmup,
        "timed_passes": args.passes,
        "mean_ms": statistics.mean(latencies),
        "median_ms": statistics.median(latencies),
        "sd_ms": statistics.stdev(latencies) if len(latencies) > 1 else 0.0,
        "peak_gpu_mb": torch.cuda.max_memory_allocated() / (1024**2) if device.type == "cuda" else None,
        "trainable_parameters": count_trainable_parameters(model),
        "scope": "model_forward_only_preprocessing_excluded",
    }
    if args.output:
        destination = Path(args.output)
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()

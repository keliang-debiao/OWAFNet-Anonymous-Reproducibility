#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats


def holm_two(p_values: list[float]) -> list[float]:
    order = np.argsort(p_values)
    adjusted = np.empty(len(p_values), dtype=float)
    running = 0.0
    for rank, index in enumerate(order):
        value = min(1.0, (len(p_values) - rank) * p_values[index])
        running = max(running, value)
        adjusted[index] = running
    return adjusted.tolist()


def upsample_mass(mass: np.ndarray, height: int = 128, width: int = 281) -> np.ndarray:
    from scipy.ndimage import zoom

    output = zoom(mass, (height / mass.shape[0], width / mass.shape[1]), order=1)
    output = output[:height, :width]
    return output / max(output.sum(), 1.0e-12)


def spectral_flux(log_mel: np.ndarray) -> np.ndarray:
    positive_difference = np.maximum(np.diff(log_mel, axis=1, prepend=log_mel[:, :1]), 0.0)
    return np.sqrt(np.sum(positive_difference**2, axis=0))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--outputs", required=True, help="NPZ from export_model_outputs.py")
    parser.add_argument("--split-file", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    arrays = np.load(args.outputs)
    identifiers = arrays["item_id"].astype(str)
    labels = arrays["labels"].astype(int)
    probabilities = arrays["probabilities"]
    attention = arrays["attention_mass"]
    prediction = (probabilities > 0.5).astype(int)
    correct = np.all(prediction == labels, axis=1)
    confidence = np.minimum(np.where(prediction == 1, probabilities, 1 - probabilities), axis=1)
    quadrants = labels[:, 0] * 2 + labels[:, 1]
    selected = []
    for quadrant in range(4):
        candidates = np.flatnonzero(correct & (quadrants == quadrant))
        if len(candidates) < 20:
            raise ValueError(f"Quadrant {quadrant} has only {len(candidates)} correctly classified items; 20 required")
        selected.extend(candidates[np.argsort(confidence[candidates])[-20:]])

    split = pd.read_csv(args.split_file, dtype={"item_id": str}).set_index("item_id")
    import librosa

    mel_centers = librosa.mel_frequencies(n_mels=128, fmin=0.0, fmax=8000.0, htk=False)
    frequency_mask = (mel_centers >= 1000.0) & (mel_centers <= 4000.0)
    records = []
    for index in selected:
        identifier = identifiers[index]
        feature = np.load(split.loc[identifier, "feature_path"], allow_pickle=False)
        if feature.ndim == 4:
            feature = feature[0]
        log_mel = feature[0]
        mass = upsample_mass(attention[index])
        flux = spectral_flux(log_mel)
        threshold = np.quantile(flux, 0.75)
        high_flux = flux >= threshold
        records.append(
            {
                "item_id": identifier,
                "arousal": int(labels[index, 0]),
                "valence": int(labels[index, 1]),
                "high_flux_mass": float(mass[:, high_flux].sum()),
                "one_to_four_khz_mass": float(mass[frequency_mask, :].sum()),
            }
        )
    frame = pd.DataFrame(records)
    arousal_high = frame.loc[frame["arousal"] == 1, "high_flux_mass"]
    arousal_low = frame.loc[frame["arousal"] == 0, "high_flux_mass"]
    valence_high = frame.loc[frame["valence"] == 1, "one_to_four_khz_mass"]
    valence_low = frame.loc[frame["valence"] == 0, "one_to_four_khz_mass"]
    p_values = [
        stats.mannwhitneyu(arousal_high, arousal_low, alternative="two-sided").pvalue,
        stats.mannwhitneyu(valence_high, valence_low, alternative="two-sided").pvalue,
    ]
    adjusted = holm_two(p_values)
    result = {
        "selection": "20 correctly classified items per quadrant ranked by minimum two-task confidence",
        "arousal_high_flux": {"high_mean": float(arousal_high.mean()), "high_sd": float(arousal_high.std(ddof=1)), "low_mean": float(arousal_low.mean()), "low_sd": float(arousal_low.std(ddof=1)), "holm_p": adjusted[0]},
        "valence_1_4khz": {"high_mean": float(valence_high.mean()), "high_sd": float(valence_high.std(ddof=1)), "low_mean": float(valence_low.mean()), "low_sd": float(valence_low.std(ddof=1)), "holm_p": adjusted[1]},
        "records": records,
    }
    destination = Path(args.output)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps({key: value for key, value in result.items() if key != "records"}, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()

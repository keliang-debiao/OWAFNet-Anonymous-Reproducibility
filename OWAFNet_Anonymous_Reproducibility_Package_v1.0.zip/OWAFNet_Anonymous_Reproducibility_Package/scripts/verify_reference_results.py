#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

from owafnet.analysis import seed_summary
from owafnet.metrics import multitask_metrics


ROOT = Path(__file__).resolve().parents[1]


def close(actual: float, expected: float, places: int) -> bool:
    return round(float(actual), places) == round(float(expected), places)


def main() -> None:
    expected = json.loads((ROOT / "results/reference/expected_results.json").read_text(encoding="utf-8"))
    frame = pd.read_csv(ROOT / "results/reference/reference_predictions_seed42.csv")
    if set(frame["artifact_status"]) != {"reference_fixture_not_empirical"}:
        raise AssertionError("Reference prediction marker is missing")
    labels = frame[["y_arousal", "y_valence"]].to_numpy(dtype=int)
    probabilities = frame[["p_arousal", "p_valence"]].to_numpy(dtype=float)
    metrics = multitask_metrics(labels, probabilities, threshold=0.5, ece_bins=15)

    checks = {}
    for task in ("arousal", "valence"):
        checks[f"{task}_confusion"] = metrics[task]["confusion"] == expected["confusion"][task]
        checks[f"{task}_f1"] = close(metrics[task]["support_weighted_f1"], expected["pmemo_model_comparison"]["owafnet"][f"{task}_f1"], 4)
        checks[f"{task}_brier"] = close(metrics[task]["brier"], expected["calibration"][task]["brier"], 3)
        checks[f"{task}_ece"] = close(metrics[task]["ece"], expected["calibration"][task]["ece_15"], 3)
    checks["average_f1"] = close(metrics["average_f1"], 0.8954, 4)

    seed_checks = {}
    for model, values in expected["seed_runs"].items():
        summary = seed_summary(values)
        seed_checks[model] = summary
    checks["owafnet_seed_mean"] = close(seed_checks["owafnet"]["mean"], 0.89520, 5)
    checks["owafnet_seed_sd"] = close(seed_checks["owafnet"]["sample_sd"], 0.00091, 5)
    checks["owafnet_ci_low"] = close(seed_checks["owafnet"]["ci_low"], 0.89407, 5)
    checks["owafnet_ci_high"] = close(seed_checks["owafnet"]["ci_high"], 0.89633, 5)

    verified_metrics = {
        "arousal": {key: metrics["arousal"][key] for key in ("support_weighted_f1", "class_f1", "brier", "ece", "confusion", "support")},
        "valence": {key: metrics["valence"][key] for key in ("support_weighted_f1", "class_f1", "brier", "ece", "confusion", "support")},
        "average_f1": metrics["average_f1"],
    }
    report = {"status": "passed" if all(checks.values()) else "failed", "checks": checks, "verified_fixture_metrics": verified_metrics, "seed_summaries": seed_checks}
    destination = ROOT / "results/reference/reference_verification.json"
    destination.write_text(json.dumps(report, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps(report, indent=2, sort_keys=True))
    if report["status"] != "passed":
        raise SystemExit(1)


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

import numpy as np
import pandas as pd

from owafnet.config import load_yaml
from owafnet.preprocessing import preprocess_item


def process(row: dict, config: dict, root: str, overwrite: bool) -> dict:
    repository = Path(root)
    audio = Path(str(row["audio_path"]))
    if not audio.is_absolute():
        audio = repository / audio
    output = Path(str(row["feature_path"]))
    if not output.is_absolute():
        output = repository / output
    if output.exists() and not overwrite:
        array = np.load(output, allow_pickle=False)
        status = "existing"
    else:
        array = preprocess_item(audio, config)
        output.parent.mkdir(parents=True, exist_ok=True)
        np.save(output, array, allow_pickle=False)
        status = "written"
    return {
        "item_id": str(row["item_id"]),
        "status": status,
        "shape": list(array.shape),
        "dtype": str(array.dtype),
        "minimum": float(array.min()),
        "maximum": float(array.max()),
        "sha256": hashlib.sha256(output.read_bytes()).hexdigest(),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--split-file", required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument("--repository-root", default=".")
    args = parser.parse_args()
    config = load_yaml(args.config)
    frame = pd.read_csv(args.split_file, dtype={"item_id": str})
    rows = frame.to_dict(orient="records")
    results = []
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        jobs = [pool.submit(process, row, config, args.repository_root, args.overwrite) for row in rows]
        for job in as_completed(jobs):
            results.append(job.result())
    results.sort(key=lambda item: item["item_id"])
    audit = {
        "dataset": config["dataset"]["name"],
        "items": len(results),
        "written": sum(item["status"] == "written" for item in results),
        "existing": sum(item["status"] == "existing" for item in results),
        "shapes": sorted({tuple(item["shape"]) for item in results}),
        "minimum": min(item["minimum"] for item in results),
        "maximum": max(item["maximum"] for item in results),
        "records": results,
    }
    destination = Path(args.split_file).with_suffix(".preprocessing.json")
    destination.write_text(json.dumps(audit, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps({key: value for key, value in audit.items() if key != "records"}, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()

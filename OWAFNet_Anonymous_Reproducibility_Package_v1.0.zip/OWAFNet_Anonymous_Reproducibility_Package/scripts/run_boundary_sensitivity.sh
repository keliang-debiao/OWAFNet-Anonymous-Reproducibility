#!/usr/bin/env bash
set -euo pipefail

for boundary in 0.40 0.45 0.50 0.55 0.60; do
  tag="${boundary/./_}"
  split="runs/pmemo/boundary_${tag}/split.csv"
  python scripts/prepare_boundary_split.py --split-file splits/pmemo_seed42.csv --boundary "${boundary}" --output "${split}"
  python scripts/train.py \
    --dataset-config configs/datasets/pmemo.yaml \
    --model-config configs/models/owafnet.yaml \
    --split-file "${split}" \
    --seed 42 \
    --output-dir "runs/pmemo/boundary_${tag}"
done

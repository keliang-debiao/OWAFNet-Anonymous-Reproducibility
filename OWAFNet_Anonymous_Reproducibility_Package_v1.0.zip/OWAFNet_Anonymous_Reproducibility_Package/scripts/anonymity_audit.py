#!/usr/bin/env python3
from __future__ import annotations

import argparse
import re
from pathlib import Path


TEXT_SUFFIXES = {".py", ".md", ".txt", ".yaml", ".yml", ".json", ".csv", ".log", ".toml", ".cff", ".sh"}
PATTERNS = {
    "email": re.compile(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", re.I),
    "home_path": re.compile(r"/(?:home|Users)/[^/\s]+"),
    "windows_user_path": re.compile(r"[A-Za-z]:\\Users\\[^\\\s]+"),
    "access_token": re.compile(r"(?:ghp_|github_pat_|hf_|sk-)[A-Za-z0-9_-]{12,}"),
}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("root", nargs="?", default=".")
    args = parser.parse_args()
    findings = []
    root = Path(args.root)
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.suffix not in TEXT_SUFFIXES or ".git" in path.parts:
            continue
        try:
            lines = path.read_text(encoding="utf-8").splitlines()
        except UnicodeDecodeError:
            continue
        for number, line in enumerate(lines, start=1):
            for name, pattern in PATTERNS.items():
                if pattern.search(line):
                    findings.append((str(path.relative_to(root)), number, name))
    if findings:
        for path, number, name in findings:
            print(f"{path}:{number}: potential_{name}")
        raise SystemExit(1)
    print("Anonymous text audit passed: no configured identity or credential patterns found.")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Generate clearly marked synthetic fixtures from manuscript-level summaries."""
from __future__ import annotations

import csv
import json
import math
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def prediction_rows() -> list[dict]:
    n = 119
    arousal_tn_probability = 0.037 * n / 62
    arousal_group_rate = 45 / 57
    arousal_delta = 0.00376733510719439
    arousal_fp_probability = arousal_group_rate + arousal_delta
    arousal_tp_probability = arousal_group_rate - (12 / 45) * arousal_delta

    valence_rate = 57 / 68
    valence_base = (49 * (2 / 51) ** 2 + 2 * (1 - 2 / 51) ** 2 + 11 * valence_rate**2 + 57 * (1 - valence_rate) ** 2) / n
    valence_group_error = math.sqrt(0.096 - valence_base)
    valence_low_probability = 2 / 51 + valence_group_error
    valence_high_probability = valence_rate - valence_group_error

    rows = []
    for index in range(n):
        y_arousal = 0 if index < 74 else 1
        pred_arousal = 1 if index >= 62 else 0
        if y_arousal == 0 and pred_arousal == 0:
            p_arousal = arousal_tn_probability
        elif y_arousal == 0:
            p_arousal = arousal_fp_probability
        else:
            p_arousal = arousal_tp_probability

        y_valence = 0 if index < 60 else 1
        pred_valence = 1 if 49 <= index < 60 or index >= 62 else 0
        p_valence = valence_high_probability if pred_valence == 1 else valence_low_probability
        rows.append(
            {
                "artifact_status": "reference_fixture_not_empirical",
                "item_id": f"reference_item_{index + 1:03d}",
                "y_arousal": y_arousal,
                "y_valence": y_valence,
                "p_arousal": f"{p_arousal:.12f}",
                "p_valence": f"{p_valence:.12f}",
                "pred_arousal": pred_arousal,
                "pred_valence": pred_valence,
            }
        )
    return rows


def write_predictions() -> None:
    destination = ROOT / "results/reference/reference_predictions_seed42.csv"
    rows = prediction_rows()
    with destination.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def write_logs() -> None:
    directory = ROOT / "logs/reference_only"
    directory.mkdir(parents=True, exist_ok=True)
    seed_values = {
        "cnn": [0.8174, 0.8139, 0.8198, 0.8147, 0.8191],
        "bilstm": [0.8321, 0.8287, 0.8349, 0.8306, 0.8335],
        "transformer": [0.8655, 0.8632, 0.8674, 0.8641, 0.8661],
        "resnet18": [0.8726, 0.8704, 0.8741, 0.8713, 0.8732],
        "owafnet": [0.8954, 0.8947, 0.8962, 0.8939, 0.8958],
    }
    seeds = [42, 123, 456, 789, 1000]
    lines = [
        "ARTIFACT_STATUS=REFERENCE_ONLY_NOT_AN_EXECUTION_RECORD",
        "PURPOSE=Expected terminal summaries for reproduction guidance",
    ]
    for model, values in seed_values.items():
        for seed, value in zip(seeds, values):
            lines.append(f"dataset=pmemo model={model} seed={seed} expected_test_average_f1={value:.4f}")
    (directory / "pmemo_seed_sweep_reference.log").write_text("\n".join(lines) + "\n", encoding="utf-8")

    trajectory = [
        "ARTIFACT_STATUS=REFERENCE_ONLY_SYNTHETIC_TRAJECTORY",
        "PURPOSE=Parser and workflow demonstration; epoch values are not empirical",
        "epoch=1 train_loss=1.2140 validation_loss=1.1870 validation_average_f1=0.6812 learning_rate=0.000500",
        "epoch=10 train_loss=0.8210 validation_loss=0.8020 validation_average_f1=0.8175 learning_rate=0.000500",
        "epoch=20 train_loss=0.6120 validation_loss=0.6410 validation_average_f1=0.8628 learning_rate=0.000500",
        "epoch=30 train_loss=0.4930 validation_loss=0.5780 validation_average_f1=0.8841 learning_rate=0.000500",
        "epoch=40 train_loss=0.4170 validation_loss=0.5520 validation_average_f1=0.8919 learning_rate=0.000250",
        "epoch=47 train_loss=0.3890 validation_loss=0.5470 validation_average_f1=0.8948 learning_rate=0.000250 best_reference_epoch=true",
        "expected_test_arousal_f1=0.9006 expected_test_valence_f1=0.8902 expected_test_average_f1=0.8954",
    ]
    (directory / "pmemo_owafnet_seed42_reference_trajectory.log").write_text("\n".join(trajectory) + "\n", encoding="utf-8")

    deam = [
        "ARTIFACT_STATUS=REFERENCE_ONLY_NOT_AN_EXECUTION_RECORD",
        "PURPOSE=Expected terminal summaries for reproduction guidance",
        "dataset=deam model=cnn expected_arousal_f1=0.8427 expected_valence_f1=0.8123 expected_average_f1=0.8275",
        "dataset=deam model=bilstm expected_arousal_f1=0.8504 expected_valence_f1=0.8248 expected_average_f1=0.8376",
        "dataset=deam model=transformer expected_arousal_f1=0.8768 expected_valence_f1=0.8564 expected_average_f1=0.8666",
        "dataset=deam model=resnet18 expected_arousal_f1=0.8839 expected_valence_f1=0.8671 expected_average_f1=0.8755",
        "dataset=deam model=owafnet expected_arousal_f1=0.9012 expected_valence_f1=0.8846 expected_average_f1=0.8929",
    ]
    (directory / "deam_seed42_reference.log").write_text("\n".join(deam) + "\n", encoding="utf-8")

    hardware = {
        "artifact_status": "manuscript_reference_not_a_local_system_probe",
        "gpu": "NVIDIA GeForce RTX 4090",
        "cuda": "12.1",
        "cpu": "Intel Xeon Gold 6248R",
        "system_memory": "128 GB DDR4 ECC",
        "pytorch": "2.2.1",
        "cpu_threads": 1,
        "batch_size": 1,
        "warmup_passes": 100,
        "timed_passes": 1000,
        "preprocessing_included": False,
    }
    (directory / "hardware_protocol_reference.json").write_text(json.dumps(hardware, indent=2), encoding="utf-8")


if __name__ == "__main__":
    write_predictions()
    write_logs()

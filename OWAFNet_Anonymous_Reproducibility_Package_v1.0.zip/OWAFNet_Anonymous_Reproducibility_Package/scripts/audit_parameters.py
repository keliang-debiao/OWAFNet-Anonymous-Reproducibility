#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json


def documented_owafnet_count() -> dict[str, int]:
    conv = (32 * (1 * 3 * 3 + 1) + 2 * 32) + (64 * (32 * 3 * 3 + 1) + 2 * 64) + (64 * (64 * 3 * 3 + 1) + 2 * 64)
    attention = 4 * 64 * 64 + 4 * 64
    se = 64 * 4 + 4 + 4 * 64 + 64
    local_conv = 64 * 64 + 64
    local_projection = 1344 * 64 + 64
    classifier = 128 * 128 + 128 + 128 * 2 + 2
    components = {
        "convolutional_frontend": conv,
        "window_multihead_attention": attention,
        "se_recalibration": se,
        "local_1x1_convolution": local_conv,
        "local_1344_to_64_projection": local_projection,
        "classifier_128_to_128_to_2": classifier,
    }
    components["total"] = sum(components.values())
    return components


def baseline_counts() -> dict[str, int]:
    return {
        "cnn": 519730,
        "bilstm": 750626,
        "transformer": 2377858,
        "resnet18": 11615202,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--strict", action="store_true")
    args = parser.parse_args()
    reported = 680578
    components = documented_owafnet_count()
    result = {
        "status": "unresolved_mismatch" if components["total"] != reported else "matched",
        "owafnet": {
            "components": components,
            "manuscript_reported": reported,
            "difference": reported - components["total"],
        },
        "baseline_literal_counts": baseline_counts(),
    }
    print(json.dumps(result, indent=2, sort_keys=True))
    if args.strict and result["status"] != "matched":
        raise SystemExit(1)


if __name__ == "__main__":
    main()

#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 2 ]]; then
  echo "Usage: bash scripts/run_local_seed_sweep.sh DATASET MODEL" >&2
  exit 2
fi

dataset="$1"
model="$2"
for seed in 42 123 456 789 1000; do
  python scripts/train.py \
    --dataset-config "configs/datasets/${dataset}.yaml" \
    --model-config "configs/models/${model}.yaml" \
    --split-file "splits/${dataset}_seed42.csv" \
    --seed "${seed}" \
    --output-dir "runs/${dataset}/${model}/seed${seed}"
done

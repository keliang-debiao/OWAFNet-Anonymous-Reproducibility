#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from owafnet.analysis import absolute_cosine


def centered_linear_cka(first: np.ndarray, second: np.ndarray) -> float:
    first = first - first.mean(axis=0, keepdims=True)
    second = second - second.mean(axis=0, keepdims=True)
    numerator = np.linalg.norm(first.T @ second, ord="fro") ** 2
    denominator = np.linalg.norm(first.T @ first, ord="fro") * np.linalg.norm(second.T @ second, ord="fro")
    return float(numerator / max(denominator, 1.0e-12))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--descriptors", required=True, help="NPZ containing global, local, and residual arrays")
    parser.add_argument("--resamples", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    arrays = np.load(args.descriptors)
    global_descriptor = arrays["global"]
    local_descriptor = arrays["local"]
    residual_descriptor = arrays["residual"]
    before = absolute_cosine(global_descriptor, local_descriptor)
    after = absolute_cosine(global_descriptor, residual_descriptor)
    reduction = before - after
    rng = np.random.default_rng(args.seed)
    boot = np.empty(args.resamples)
    for index in range(args.resamples):
        selected = rng.integers(0, len(reduction), len(reduction))
        boot[index] = reduction[selected].mean()
    result = {
        "before_mean_absolute_cosine": float(before.mean()),
        "before_sd": float(before.std(ddof=1)),
        "after_mean_absolute_cosine": float(after.mean()),
        "after_sd": float(after.std(ddof=1)),
        "before_centered_linear_cka": centered_linear_cka(global_descriptor, local_descriptor),
        "after_centered_linear_cka": centered_linear_cka(global_descriptor, residual_descriptor),
        "mean_cosine_reduction": float(reduction.mean()),
        "bootstrap_ci": np.quantile(boot, [0.025, 0.975]).tolist(),
        "bootstrap_resamples": args.resamples,
        "seed": args.seed,
    }
    destination = Path(args.output)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()

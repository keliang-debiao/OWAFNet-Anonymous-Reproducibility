#!/usr/bin/env python3
from __future__ import annotations

import argparse
import itertools
import json
from pathlib import Path

import numpy as np

from owafnet.config import load_yaml


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/hyperparameter_grid.yaml")
    parser.add_argument("--output", default="results/search_schedule_seed42.json")
    args = parser.parse_args()
    section = load_yaml(args.config)["local_models"]
    grid = section["grid"]
    names = ["learning_rate", "weight_decay", "dropout", "batch_size"]
    combinations = [dict(zip(names, values)) for values in itertools.product(*(grid[name] for name in names))]
    rng = np.random.default_rng(int(section["generator_seed"]))
    selected = rng.choice(len(combinations), size=int(section["sample_without_replacement"]), replace=False)
    schedule = {"generator_seed": int(section["generator_seed"]), "candidate_count": len(combinations), "selected": [combinations[i] for i in selected]}
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(schedule, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps(schedule, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()

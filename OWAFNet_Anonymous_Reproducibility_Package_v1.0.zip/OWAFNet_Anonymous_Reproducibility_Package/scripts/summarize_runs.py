#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

from owafnet.analysis import seed_summary


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--runs-root", default="runs")
    parser.add_argument("--output-dir", default="results/reproduced")
    args = parser.parse_args()
    records = []
    for path in sorted(Path(args.runs_root).glob("**/summary.json")):
        summary = json.loads(path.read_text(encoding="utf-8"))
        relative = path.relative_to(args.runs_root)
        parts = relative.parts
        if len(parts) < 4:
            continue
        records.append(
            {
                "dataset": parts[0],
                "model": parts[1],
                "seed": int(summary["seed"]),
                "arousal_f1": summary["test_metrics"]["arousal"]["support_weighted_f1"],
                "valence_f1": summary["test_metrics"]["valence"]["support_weighted_f1"],
                "average_f1": summary["test_metrics"]["average_f1"],
                "run": str(relative.parent),
            }
        )
    if not records:
        raise FileNotFoundError("No run summary files were found")
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    frame = pd.DataFrame(records)
    frame.to_csv(output / "all_runs.csv", index=False)
    summaries = []
    for (dataset, model), group in frame.groupby(["dataset", "model"]):
        statistics = seed_summary(group["average_f1"].to_numpy()) if len(group) > 1 else {}
        summaries.append({"dataset": dataset, "model": model, "runs": len(group), **statistics})
    pd.DataFrame(summaries).to_csv(output / "seed_summaries.csv", index=False)
    print(pd.DataFrame(summaries).to_string(index=False))


if __name__ == "__main__":
    main()

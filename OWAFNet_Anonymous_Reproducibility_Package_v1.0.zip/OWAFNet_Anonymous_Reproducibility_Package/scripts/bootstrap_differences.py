#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

from owafnet.analysis import paired_song_bootstrap


def load(path: str) -> pd.DataFrame:
    frame = pd.read_csv(path, dtype={"item_id": str})
    required = {"item_id", "y_arousal", "y_valence", "p_arousal", "p_valence"}
    if not required.issubset(frame.columns):
        raise ValueError(f"{path} lacks {sorted(required - set(frame.columns))}")
    return frame


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--primary", required=True)
    parser.add_argument("--comparison", required=True)
    parser.add_argument("--resamples", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    primary = load(args.primary)
    comparison = load(args.comparison)
    merged = primary.merge(comparison, on="item_id", suffixes=("_primary", "_comparison"), validate="one_to_one")
    for task in ("arousal", "valence"):
        if not (merged[f"y_{task}_primary"] == merged[f"y_{task}_comparison"]).all():
            raise ValueError(f"Labels differ for {task}")
    labels = merged[["y_arousal_primary", "y_valence_primary"]].to_numpy()
    primary_probabilities = merged[["p_arousal_primary", "p_valence_primary"]].to_numpy()
    comparison_probabilities = merged[["p_arousal_comparison", "p_valence_comparison"]].to_numpy()
    result = paired_song_bootstrap(labels, primary_probabilities, comparison_probabilities, args.resamples, args.seed)
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()

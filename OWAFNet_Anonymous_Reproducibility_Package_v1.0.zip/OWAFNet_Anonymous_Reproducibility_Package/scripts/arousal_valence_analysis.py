#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", required=True, help="794-row PMEmo audit manifest")
    parser.add_argument("--predictions", nargs="+", required=True, help="Five test prediction CSV files")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    if len(args.predictions) != 5:
        raise ValueError("Exactly five seed-level prediction files are required")
    frame = pd.read_csv(args.manifest, dtype={"item_id": str})
    required = {"item_id", "normalized_arousal", "normalized_valence", "arousal_sd", "valence_sd", "rms_energy", "spectral_flux"}
    missing = required - set(frame.columns)
    if missing:
        raise ValueError(f"Audit manifest lacks columns required for Table S11: {sorted(missing)}")
    correlations = {
        "arousal_rms": abs(float(stats.spearmanr(frame["rms_energy"], frame["normalized_arousal"]).statistic)),
        "valence_rms": abs(float(stats.spearmanr(frame["rms_energy"], frame["normalized_valence"]).statistic)),
        "arousal_flux": abs(float(stats.spearmanr(frame["spectral_flux"], frame["normalized_arousal"]).statistic)),
        "valence_flux": abs(float(stats.spearmanr(frame["spectral_flux"], frame["normalized_valence"]).statistic)),
    }
    wilcoxon = stats.wilcoxon(frame["arousal_sd"], frame["valence_sd"], alternative="two-sided")

    per_seed = []
    for path in args.predictions:
        prediction = pd.read_csv(path, dtype={"item_id": str})
        joined = frame.merge(prediction, on="item_id", suffixes=("_manifest", "_prediction"), validate="one_to_one")
        record = {}
        for task in ("arousal", "valence"):
            if not (joined[f"y_{task}_manifest"] == joined[f"y_{task}_prediction"]).all():
                raise ValueError(f"Manifest and prediction labels differ for {task}")
            near = np.abs(joined[f"normalized_{task}"] - 0.5) <= 0.10
            error = joined[f"y_{task}_manifest"] != joined[f"pred_{task}"]
            record[f"{task}_near_size"] = int(near.sum())
            record[f"{task}_other_size"] = int((~near).sum())
            record[f"{task}_near_error"] = float(error[near].mean())
            record[f"{task}_other_error"] = float(error[~near].mean())
        per_seed.append(record)
    result = {
        "mean_annotation_sd": {"arousal": float(frame["arousal_sd"].mean()), "valence": float(frame["valence_sd"].mean())},
        "paired_wilcoxon_p": float(wilcoxon.pvalue),
        "absolute_spearman": correlations,
        "five_seed_boundary_summary": {key: float(np.mean([record[key] for record in per_seed])) for key in per_seed[0]},
        "per_seed": per_seed,
    }
    destination = Path(args.output)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()

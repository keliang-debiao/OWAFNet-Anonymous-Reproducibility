#!/usr/bin/env python3
from __future__ import annotations

import itertools
import json
from pathlib import Path

from owafnet.config import load_yaml


def main() -> None:
    config = load_yaml("configs/hyperparameter_grid.yaml")
    output = {}
    for regime in ("pretrained_frozen_probe", "pretrained_fine_tuning"):
        section = config[regime]
        names = ["learning_rate", "weight_decay", "batch_size"]
        trials = [dict(zip(names, values)) for values in itertools.product(*(section[name] for name in names))]
        if len(trials) != int(section["trials"]):
            raise AssertionError(f"{regime} grid does not contain 24 trials")
        output[regime] = trials
    destination = Path("results/pretrained_search_schedule.json")
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(output, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()

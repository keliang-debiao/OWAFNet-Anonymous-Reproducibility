#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

import yaml

from owafnet.config import deep_merge, load_yaml
from owafnet.models import build_model, count_trainable_parameters
from owafnet.training import fit


def apply_overrides(config, overrides):
    for expression in overrides:
        if "=" not in expression:
            raise ValueError(f"Override must be KEY=VALUE: {expression}")
        key, raw = expression.split("=", 1)
        destination = config
        parts = key.split(".")
        for part in parts[:-1]:
            destination = destination.setdefault(part, {})
        destination[parts[-1]] = yaml.safe_load(raw)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset-config", required=True)
    parser.add_argument("--model-config", required=True)
    parser.add_argument("--split-file", required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--strict-parameters", action="store_true")
    parser.add_argument("--set", action="append", default=[], metavar="KEY=VALUE")
    args = parser.parse_args()

    config = deep_merge(load_yaml(args.dataset_config), load_yaml(args.model_config))
    apply_overrides(config, args.set)
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    (output / "resolved_config.json").write_text(json.dumps(config, indent=2, sort_keys=True), encoding="utf-8")
    model = build_model(config)
    actual = count_trainable_parameters(model)
    reported = int(config["model"].get("reported_parameters", actual))
    parameter_record = {"actual_trainable_parameters": actual, "reported_parameters": reported, "matches": actual == reported}
    (output / "parameter_count.json").write_text(json.dumps(parameter_record, indent=2), encoding="utf-8")
    if args.strict_parameters and actual != reported:
        raise RuntimeError(f"Parameter mismatch: implementation={actual}, manuscript={reported}")
    if actual != reported:
        print(f"WARNING: parameter mismatch: implementation={actual}, manuscript={reported}")
    summary = fit(model, config, args.split_file, args.seed, output)
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()

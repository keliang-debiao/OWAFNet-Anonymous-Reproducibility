#!/usr/bin/env bash
set -euo pipefail

base=(python scripts/train.py --dataset-config configs/datasets/pmemo.yaml --model-config configs/models/owafnet.yaml --split-file splits/pmemo_seed42.csv --seed 42)

"${base[@]}" --set model.fusion=addition --output-dir runs/pmemo/ablation/fusion_addition
"${base[@]}" --set model.fusion=concatenation --output-dir runs/pmemo/ablation/fusion_concatenation
"${base[@]}" --set model.fusion=learned_gate --output-dir runs/pmemo/ablation/fusion_learned_gate
"${base[@]}" --set model.fusion=orthogonal --output-dir runs/pmemo/ablation/fusion_orthogonal

"${base[@]}" --set model.recalibration=none --output-dir runs/pmemo/ablation/recalibration_none
"${base[@]}" --set model.recalibration=cbam --output-dir runs/pmemo/ablation/recalibration_cbam
"${base[@]}" --set model.recalibration=dynamic_cbam --output-dir runs/pmemo/ablation/recalibration_dynamic_cbam
"${base[@]}" --set model.recalibration=se --output-dir runs/pmemo/ablation/recalibration_se

"${base[@]}" --set model.context=none --output-dir runs/pmemo/ablation/context_none
"${base[@]}" --set model.context=double_attention --output-dir runs/pmemo/ablation/context_double_attention
"${base[@]}" --set model.context=ufo_attention --output-dir runs/pmemo/ablation/context_ufo_attention
"${base[@]}" --set model.context=full_attention --output-dir runs/pmemo/ablation/context_full_attention
"${base[@]}" --set model.context=window --output-dir runs/pmemo/ablation/context_window

"${base[@]}" --output-dir runs/pmemo/ablation/removal_full
"${base[@]}" --set model.context=none --output-dir runs/pmemo/ablation/removal_without_window_attention
"${base[@]}" --set model.recalibration=none --output-dir runs/pmemo/ablation/removal_without_se
"${base[@]}" --set model.fusion=global_only --output-dir runs/pmemo/ablation/removal_without_orthogonal_fusion
"${base[@]}" --set model.local_channels=32 --output-dir runs/pmemo/ablation/removal_reduced_local_capacity

"${base[@]}" --set augmentation.rolling.enabled=false --set augmentation.masking.enabled=false --output-dir runs/pmemo/ablation/augmentation_none
"${base[@]}" --set augmentation.rolling.enabled=true --set augmentation.masking.enabled=false --output-dir runs/pmemo/ablation/augmentation_rolling
"${base[@]}" --set augmentation.rolling.enabled=false --set augmentation.masking.enabled=true --output-dir runs/pmemo/ablation/augmentation_masking
"${base[@]}" --set augmentation.rolling.enabled=true --set augmentation.masking.enabled=true --output-dir runs/pmemo/ablation/augmentation_both

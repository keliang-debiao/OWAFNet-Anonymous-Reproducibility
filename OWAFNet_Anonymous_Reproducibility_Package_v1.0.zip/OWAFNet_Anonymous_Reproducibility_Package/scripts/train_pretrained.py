#!/usr/bin/env python3
from __future__ import annotations

import argparse
import inspect
import json
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from torch.nn import functional as F
from torch.utils.data import DataLoader
from transformers import AutoFeatureExtractor

from owafnet.config import load_yaml
from owafnet.metrics import multitask_metrics
from owafnet.preprocessing import center_crop_or_symmetric_pad, load_mono_resampled
from owafnet.pretrained import build_pretrained
from owafnet.reproducibility import environment_snapshot, seed_everything


class RawAudioDataset:
    def __init__(self, split_file: str, split: str, sample_rate: int, target_samples: int, repository_root: str):
        frame = pd.read_csv(split_file, dtype={"item_id": str})
        self.frame = frame.loc[frame["split"] == split].reset_index(drop=True)
        self.sample_rate = sample_rate
        self.target_samples = target_samples
        self.root = Path(repository_root)

    def __len__(self):
        return len(self.frame)

    def __getitem__(self, index):
        row = self.frame.iloc[index]
        path = Path(str(row["audio_path"]))
        if not path.is_absolute():
            path = self.root / path
        waveform = center_crop_or_symmetric_pad(load_mono_resampled(path, self.sample_rate), self.target_samples)
        return str(row["item_id"]), waveform, np.asarray([row["y_arousal"], row["y_valence"]], dtype=np.float32)


class ProcessorCollator:
    def __init__(self, checkpoint: str, sample_rate: int):
        self.processor = AutoFeatureExtractor.from_pretrained(checkpoint)
        self.sample_rate = sample_rate

    def __call__(self, batch):
        identifiers, waveforms, targets = zip(*batch)
        encoded = self.processor(list(waveforms), sampling_rate=self.sample_rate, padding=True, return_tensors="pt")
        return {"item_id": list(identifiers), "encoded": dict(encoded), "targets": torch.from_numpy(np.stack(targets))}


def forward(model, encoded, device):
    moved = {key: value.to(device) for key, value in encoded.items()}
    parameters = inspect.signature(model.forward).parameters
    accepted = {key: value for key, value in moved.items() if key in parameters}
    return model(**accepted)


def run_epoch(model, loader, device, optimizer=None, frozen=False):
    training = optimizer is not None
    model.train(training)
    if training and frozen:
        model.encoder.eval()
    losses, identifiers, labels, probabilities = [], [], [], []
    for batch in loader:
        targets = batch["targets"].to(device)
        with torch.set_grad_enabled(training):
            logits = forward(model, batch["encoded"], device)
            loss = F.binary_cross_entropy_with_logits(logits, targets, reduction="none").sum(dim=1).mean()
            if training:
                optimizer.zero_grad(set_to_none=True)
                loss.backward()
                optimizer.step()
        losses.append(float(loss.detach().cpu()))
        identifiers.extend(batch["item_id"])
        labels.append(targets.detach().cpu().numpy())
        probabilities.append(torch.sigmoid(logits).detach().cpu().numpy())
    return float(np.mean(losses)), identifiers, np.concatenate(labels), np.concatenate(probabilities)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset-config", default="configs/datasets/pmemo.yaml")
    parser.add_argument("--pretrained-config", default="configs/pretrained.yaml")
    parser.add_argument("--split-file", default="splits/pmemo_seed42.csv")
    parser.add_argument("--model", choices=["wav2vec2", "hubert", "ast"], required=True)
    parser.add_argument("--regime", choices=["fp", "ft"], required=True)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--repository-root", default=".")
    args = parser.parse_args()

    seed_everything(args.seed)
    dataset_config = load_yaml(args.dataset_config)
    pretrained = load_yaml(args.pretrained_config)
    selected = pretrained["selected"]["frozen_probe" if args.regime == "fp" else "fine_tuning"]
    checkpoint = pretrained["models"][args.model]["checkpoint"]
    frozen = args.regime == "fp"
    model = build_pretrained(args.model, checkpoint, frozen)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)
    sample_rate = int(dataset_config["audio"]["sample_rate"])
    target_samples = int(dataset_config["audio"]["target_samples"])
    collator = ProcessorCollator(checkpoint, sample_rate)
    loaders = {}
    for split in ("train", "validation", "test"):
        dataset = RawAudioDataset(args.split_file, split, sample_rate, target_samples, args.repository_root)
        loaders[split] = DataLoader(dataset, batch_size=int(selected["batch_size"]), shuffle=split == "train", num_workers=0, collate_fn=collator)

    optimizer = torch.optim.Adam(
        [parameter for parameter in model.parameters() if parameter.requires_grad],
        lr=float(selected["learning_rate"]),
        weight_decay=float(selected["weight_decay"]),
        betas=(float(dataset_config["training"]["beta1"]), float(dataset_config["training"]["beta2"])),
        eps=float(dataset_config["training"]["optimizer_epsilon"]),
    )
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer,
        mode="max",
        factor=float(dataset_config["training"]["scheduler_factor"]),
        patience=int(dataset_config["training"]["scheduler_patience"]),
        min_lr=float(dataset_config["training"]["minimum_learning_rate"]),
    )
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    best_score = -float("inf")
    early_reference = -float("inf")
    stale = 0
    checkpoint_path = output / "best_checkpoint.pt"
    with (output / "epochs.jsonl").open("w", encoding="utf-8") as log:
        for epoch in range(1, int(dataset_config["training"]["max_epochs"]) + 1):
            train_loss, _, train_labels, train_probabilities = run_epoch(model, loaders["train"], device, optimizer, frozen)
            validation_loss, _, validation_labels, validation_probabilities = run_epoch(model, loaders["validation"], device, frozen=frozen)
            train_metrics = multitask_metrics(train_labels, train_probabilities)
            validation_metrics = multitask_metrics(validation_labels, validation_probabilities)
            score = float(validation_metrics["average_f1"])
            scheduler.step(score)
            if round(score, 8) > round(best_score, 8):
                best_score = score
                torch.save({"model_state": model.state_dict(), "epoch": epoch, "seed": args.seed, "validation_average_f1": score}, checkpoint_path)
            if score > early_reference + float(dataset_config["training"]["improvement_delta"]):
                early_reference, stale = score, 0
            else:
                stale += 1
            log.write(json.dumps({"epoch": epoch, "train_loss": train_loss, "validation_loss": validation_loss, "train_average_f1": train_metrics["average_f1"], "validation_average_f1": score, "learning_rate": optimizer.param_groups[0]["lr"]}) + "\n")
            log.flush()
            if stale >= int(dataset_config["training"]["early_stopping_patience"]):
                break

    state = torch.load(checkpoint_path, map_location=device)
    model.load_state_dict(state["model_state"])
    test_loss, item_ids, labels, probabilities = run_epoch(model, loaders["test"], device, frozen=frozen)
    metrics = multitask_metrics(labels, probabilities)
    prediction = pd.DataFrame({"item_id": item_ids, "y_arousal": labels[:, 0].astype(int), "y_valence": labels[:, 1].astype(int), "p_arousal": probabilities[:, 0], "p_valence": probabilities[:, 1]})
    prediction["pred_arousal"] = (prediction["p_arousal"] > 0.5).astype(int)
    prediction["pred_valence"] = (prediction["p_valence"] > 0.5).astype(int)
    prediction.to_csv(output / "test_predictions.csv", index=False)
    summary = {
        "model": args.model,
        "regime": args.regime,
        "checkpoint": checkpoint,
        "seed": args.seed,
        "best_epoch": int(state["epoch"]),
        "best_validation_average_f1": best_score,
        "test_loss": test_loss,
        "test_metrics": metrics,
        "total_parameters": sum(parameter.numel() for parameter in model.parameters()),
        "trainable_parameters": sum(parameter.numel() for parameter in model.parameters() if parameter.requires_grad),
        "augmentation_policy": "none because the manuscript does not specify a cross-frontend equivalent",
        "environment": environment_snapshot(),
    }
    (output / "summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()

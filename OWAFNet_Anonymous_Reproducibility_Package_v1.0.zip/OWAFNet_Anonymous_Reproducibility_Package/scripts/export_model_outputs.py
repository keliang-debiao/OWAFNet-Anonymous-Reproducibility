#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader

from owafnet.config import deep_merge, load_yaml
from owafnet.data import LogMelManifestDataset
from owafnet.models import OWAFNet


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset-config", required=True)
    parser.add_argument("--model-config", required=True)
    parser.add_argument("--split-file", required=True)
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--split", default="test", choices=["train", "validation", "test"])
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    config = deep_merge(load_yaml(args.dataset_config), load_yaml(args.model_config))
    dataset = LogMelManifestDataset(args.split_file, args.split, config, seed=42)
    loader = DataLoader(dataset, batch_size=int(config["optimizer"]["batch_size"]), shuffle=False, num_workers=0)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = OWAFNet(config["model"]).to(device).eval()
    checkpoint = torch.load(args.checkpoint, map_location=device)
    model.load_state_dict(checkpoint["model_state"])

    item_ids = []
    labels = []
    probabilities = []
    global_descriptors = []
    local_descriptors = []
    residual_descriptors = []
    attention_masses = []
    with torch.no_grad():
        for batch in loader:
            inputs = batch["inputs"].to(device=device, dtype=torch.float32)
            if inputs.shape[1] != 1:
                raise ValueError("Descriptor and attention export is defined for one PMEmo test input per item")
            output = model(inputs[:, 0], return_descriptors=True, return_attention_mass=True)
            item_ids.extend(batch["item_id"])
            labels.append(batch["targets"].numpy())
            probabilities.append(torch.sigmoid(output["logits"]).cpu().numpy())
            global_descriptors.append(output["global_descriptor"].cpu().numpy())
            local_descriptors.append(output["local_descriptor"].cpu().numpy())
            residual_descriptors.append(output["residual_descriptor"].cpu().numpy())
            attention_masses.append(output["attention_mass"].cpu().numpy())
    destination = Path(args.output)
    destination.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        destination,
        **{
            "item_id": np.asarray(item_ids),
            "labels": np.concatenate(labels),
            "probabilities": np.concatenate(probabilities),
            "global": np.concatenate(global_descriptors),
            "local": np.concatenate(local_descriptors),
            "residual": np.concatenate(residual_descriptors),
            "attention_mass": np.concatenate(attention_masses),
        },
    )
    print(f"Wrote {len(item_ids)} item-level records to {destination}")


if __name__ == "__main__":
    main()

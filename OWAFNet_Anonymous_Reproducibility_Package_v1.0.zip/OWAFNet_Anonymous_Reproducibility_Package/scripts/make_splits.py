#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path

import numpy as np
import pandas as pd


SETTINGS = {
    "pmemo": {
        "count": 794,
        "sizes": (556, 119, 119),
        "scale": (-1.0, 1.0),
        "full_support": {"arousal": (387, 407), "valence": (392, 402)},
        "test_support": {"arousal": (74, 45), "valence": (60, 59)},
    },
    "deam": {"count": 1802, "sizes": (1262, 270, 270), "scale": (1.0, 9.0)},
}


def feature_name(item_id: str) -> str:
    stem = re.sub(r"[^A-Za-z0-9._-]+", "_", item_id).strip("._") or "item"
    digest = hashlib.sha256(item_id.encode("utf-8")).hexdigest()[:10]
    return f"{stem[:80]}_{digest}.npy"


def main() -> None:
    parser = argparse.ArgumentParser(description="Create the fixed item-level NumPy-seed-42 split.")
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--dataset", choices=sorted(SETTINGS), required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--allow-support-mismatch", action="store_true")
    parser.add_argument("--repository-root", default=".")
    parser.add_argument("--skip-path-check", action="store_true")
    args = parser.parse_args()

    source = Path(args.manifest)
    frame = pd.read_csv(source, dtype={"item_id": str})
    required = {"item_id", "audio_path", "arousal", "valence"}
    missing = required - set(frame.columns)
    if missing:
        raise ValueError(f"Manifest lacks columns: {sorted(missing)}")
    if frame["item_id"].isna().any() or frame["item_id"].duplicated().any():
        raise ValueError("item_id must be complete and unique")
    if frame["audio_path"].isna().any():
        raise ValueError("audio_path must be complete")
    if not args.skip_path_check:
        repository = Path(args.repository_root)
        missing_paths = []
        for value in frame["audio_path"]:
            candidate = Path(str(value))
            if not candidate.is_absolute():
                candidate = repository / candidate
            if not candidate.is_file():
                missing_paths.append(str(value))
                if len(missing_paths) == 10:
                    break
        if missing_paths:
            raise FileNotFoundError(f"Audio files were not found, first entries: {missing_paths}")
    setting = SETTINGS[args.dataset]
    if len(frame) != setting["count"]:
        raise ValueError(f"Expected {setting['count']} rows, received {len(frame)}")
    for task in ("arousal", "valence"):
        frame[task] = pd.to_numeric(frame[task], errors="raise")
        if not np.isfinite(frame[task]).all():
            raise ValueError(f"Nonfinite {task} rating")
        low, high = setting["scale"]
        if not frame[task].between(low, high, inclusive="both").all():
            raise ValueError(f"{task} lies outside {setting['scale']}")
        frame[f"normalized_{task}"] = (frame[task] - low) / (high - low)
        frame[f"y_{task}"] = (frame[f"normalized_{task}"] > 0.5).astype(int)

    permutation = np.random.default_rng(args.seed).permutation(len(frame))
    train_size, validation_size, test_size = setting["sizes"]
    split = np.empty(len(frame), dtype=object)
    split[permutation[:train_size]] = "train"
    split[permutation[train_size : train_size + validation_size]] = "validation"
    split[permutation[train_size + validation_size :]] = "test"
    frame["split"] = split
    frame["source_order"] = np.arange(len(frame), dtype=int)
    frame["feature_path"] = [f"data/processed/{args.dataset}/{feature_name(value)}" for value in frame["item_id"]]

    support = {}
    for partition in ("all", "train", "validation", "test"):
        selected = frame if partition == "all" else frame.loc[frame["split"] == partition]
        support[partition] = {
            task: {"low": int(np.sum(selected[f"y_{task}"] == 0)), "high": int(np.sum(selected[f"y_{task}"] == 1))}
            for task in ("arousal", "valence")
        }
    if args.dataset == "pmemo" and not args.allow_support_mismatch:
        for task, expected in setting["full_support"].items():
            observed = (support["all"][task]["low"], support["all"][task]["high"])
            if observed != expected:
                raise ValueError(f"Full-set {task} support {observed} does not match manuscript {expected}")
        for task, expected in setting["test_support"].items():
            observed = (support["test"][task]["low"], support["test"][task]["high"])
            if observed != expected:
                raise ValueError(
                    f"Test {task} support {observed} does not match manuscript {expected}. "
                    "Check that the source manifest row order matches the experiment."
                )

    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(output, index=False)
    audit = {
        "dataset": args.dataset,
        "seed": args.seed,
        "source_manifest": source.name,
        "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
        "rows": len(frame),
        "partition_sizes": frame["split"].value_counts().to_dict(),
        "support": support,
        "order_before_shuffle": "source manifest row order",
    }
    audit_path = output.with_suffix(".audit.json")
    audit_path.write_text(json.dumps(audit, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps(audit, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()

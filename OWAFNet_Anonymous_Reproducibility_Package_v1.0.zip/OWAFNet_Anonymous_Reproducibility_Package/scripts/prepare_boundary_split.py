#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--split-file", required=True)
    parser.add_argument("--boundary", type=float, choices=[0.40, 0.45, 0.50, 0.55, 0.60], required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    frame = pd.read_csv(args.split_file, dtype={"item_id": str})
    for task in ("arousal", "valence"):
        frame[f"y_{task}"] = (frame[f"normalized_{task}"] > args.boundary).astype(int)
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(output, index=False)
    print(frame.groupby("split")[["y_arousal", "y_valence"]].agg(["count", "sum"]))


if __name__ == "__main__":
    main()

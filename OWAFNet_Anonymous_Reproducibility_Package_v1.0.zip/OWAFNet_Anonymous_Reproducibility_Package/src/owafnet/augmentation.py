from __future__ import annotations

from typing import Any


def augment_log_mel(x, config: dict[str, Any], generator):
    """Apply the manuscript's independent rolling and zero-mask operators."""
    import torch

    output = x.clone()
    rolling = config["augmentation"]["rolling"]
    if bool(rolling["enabled"]) and torch.rand((), generator=generator).item() < float(rolling["probability"]):
        low = int(rolling["min_frames"])
        high = int(rolling["max_frames"])
        shift = int(torch.randint(low, high + 1, (), generator=generator).item())
        output = torch.roll(output, shifts=shift, dims=-1)

    masking = config["augmentation"]["masking"]
    if bool(masking["enabled"]) and torch.rand((), generator=generator).item() < float(masking["probability"]):
        for _ in range(int(masking["time_masks"])):
            _mask_axis(output, -1, int(masking["max_time_width"]), float(masking["fill"]), generator)
        for _ in range(int(masking["frequency_masks"])):
            _mask_axis(output, -2, int(masking["max_frequency_width"]), float(masking["fill"]), generator)
    return output


def _mask_axis(x, axis: int, maximum_width: int, fill: float, generator) -> None:
    import torch

    length = x.shape[axis]
    width = int(torch.randint(0, maximum_width + 1, (), generator=generator).item())
    if width == 0:
        return
    start = int(torch.randint(0, length - width + 1, (), generator=generator).item())
    index = [slice(None)] * x.ndim
    index[axis] = slice(start, start + width)
    x[tuple(index)] = fill

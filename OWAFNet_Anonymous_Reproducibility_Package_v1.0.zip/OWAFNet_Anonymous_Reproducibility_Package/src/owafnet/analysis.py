from __future__ import annotations

from typing import Any

import numpy as np
from scipy import stats

from .metrics import multitask_metrics


def seed_summary(values: list[float] | np.ndarray, confidence: float = 0.95) -> dict[str, float]:
    values = np.asarray(values, dtype=float)
    if values.ndim != 1 or values.size < 2:
        raise ValueError("At least two seed values are required")
    mean = float(np.mean(values))
    standard_deviation = float(np.std(values, ddof=1))
    critical = float(stats.t.ppf((1.0 + confidence) / 2.0, df=values.size - 1))
    half_width = critical * standard_deviation / np.sqrt(values.size)
    return {"mean": mean, "sample_sd": standard_deviation, "ci_low": mean - half_width, "ci_high": mean + half_width}


def paired_song_bootstrap(
    labels: np.ndarray,
    primary_probabilities: np.ndarray,
    comparison_probabilities: np.ndarray,
    resamples: int = 10_000,
    seed: int = 42,
) -> dict[str, Any]:
    labels = np.asarray(labels)
    primary_probabilities = np.asarray(primary_probabilities)
    comparison_probabilities = np.asarray(comparison_probabilities)
    if labels.shape != primary_probabilities.shape or labels.shape != comparison_probabilities.shape:
        raise ValueError("Aligned labels and probabilities must have the same shape")
    rng = np.random.default_rng(seed)
    differences = np.empty(resamples, dtype=float)
    n_items = labels.shape[0]
    for index in range(resamples):
        sampled = rng.integers(0, n_items, size=n_items)
        primary = multitask_metrics(labels[sampled], primary_probabilities[sampled])["average_f1"]
        comparison = multitask_metrics(labels[sampled], comparison_probabilities[sampled])["average_f1"]
        differences[index] = primary - comparison
    point = multitask_metrics(labels, primary_probabilities)["average_f1"] - multitask_metrics(labels, comparison_probabilities)["average_f1"]
    low, high = np.quantile(differences, [0.025, 0.975])
    return {"difference": float(point), "ci_low": float(low), "ci_high": float(high), "resamples": int(resamples), "seed": int(seed)}


def centered_linear_cka(first: np.ndarray, second: np.ndarray) -> float:
    first = np.asarray(first, dtype=float)
    second = np.asarray(second, dtype=float)
    if first.shape[0] != second.shape[0]:
        raise ValueError("Descriptor matrices must contain the same songs")
    first = first - first.mean(axis=0, keepdims=True)
    second = second - second.mean(axis=0, keepdims=True)
    cross = first.T @ second
    numerator = np.sum(cross * cross)
    denominator = np.sqrt(np.sum((first.T @ first) ** 2) * np.sum((second.T @ second) ** 2))
    return float(numerator / denominator) if denominator > 0 else 0.0


def absolute_cosine(first: np.ndarray, second: np.ndarray, epsilon: float = 1.0e-12) -> np.ndarray:
    first = np.asarray(first, dtype=float)
    second = np.asarray(second, dtype=float)
    numerator = np.sum(first * second, axis=1)
    denominator = np.linalg.norm(first, axis=1) * np.linalg.norm(second, axis=1)
    return np.abs(numerator / np.maximum(denominator, epsilon))

from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np


def center_crop_or_symmetric_pad(waveform: np.ndarray, target_samples: int) -> np.ndarray:
    waveform = np.asarray(waveform, dtype=np.float32).reshape(-1)
    current = waveform.shape[0]
    if current == target_samples:
        return waveform
    if current > target_samples:
        start = (current - target_samples) // 2
        return waveform[start : start + target_samples]
    missing = target_samples - current
    left = missing // 2
    right = missing - left
    return np.pad(waveform, (left, right), mode="constant").astype(np.float32)


def load_mono_resampled(path: str | Path, sample_rate: int) -> np.ndarray:
    import librosa

    waveform, original_rate = librosa.load(path, sr=None, mono=True)
    if original_rate != sample_rate:
        waveform = librosa.resample(
            waveform,
            orig_sr=original_rate,
            target_sr=sample_rate,
            res_type="soxr_hq",
        )
    return np.asarray(waveform, dtype=np.float32)


def log_mel_from_waveform(waveform: np.ndarray, config: dict[str, Any]) -> np.ndarray:
    import librosa

    spec = config["spectrogram"]
    audio = config["audio"]
    power = librosa.feature.melspectrogram(
        y=np.asarray(waveform, dtype=np.float32),
        sr=int(audio["sample_rate"]),
        n_fft=int(spec["n_fft"]),
        hop_length=int(spec["hop_length"]),
        win_length=int(spec["win_length"]),
        window=str(spec["window"]),
        center=bool(spec["center"]),
        pad_mode=str(spec["pad_mode"]),
        power=float(spec["power"]),
        n_mels=int(spec["n_mels"]),
        fmin=float(spec["f_min"]),
        fmax=float(spec["f_max"]),
        norm=str(spec["mel_norm"]),
    )
    db = librosa.power_to_db(power, ref=np.max, top_db=float(spec["top_db"]))
    normalized = np.clip((db + float(spec["top_db"])) / float(spec["top_db"]), 0.0, 1.0)
    frames = int(spec["output_frames"])
    if normalized.shape[1] < frames:
        normalized = np.pad(normalized, ((0, 0), (0, frames - normalized.shape[1])))
    normalized = normalized[:, :frames]
    return normalized[np.newaxis, :, :].astype(np.float32)


def preprocess_item(path: str | Path, config: dict[str, Any]) -> np.ndarray:
    waveform = load_mono_resampled(path, int(config["audio"]["sample_rate"]))
    target_samples = int(config["audio"]["target_samples"])
    waveform = center_crop_or_symmetric_pad(waveform, target_samples)
    dataset_name = str(config["dataset"]["name"]).lower()
    if dataset_name == "pmemo":
        return log_mel_from_waveform(waveform, config)
    if dataset_name == "deam":
        window_samples = int(config["audio"]["window_samples"])
        windows = int(config["audio"]["windows_per_item"])
        return np.stack(
            [
                log_mel_from_waveform(waveform[j * window_samples : (j + 1) * window_samples], config)
                for j in range(windows)
            ],
            axis=0,
        ).astype(np.float32)
    raise ValueError(f"Unsupported dataset: {dataset_name}")

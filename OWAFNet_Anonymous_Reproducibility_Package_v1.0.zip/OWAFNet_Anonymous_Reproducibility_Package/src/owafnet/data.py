from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from .augmentation import augment_log_mel


class LogMelManifestDataset:
    def __init__(self, split_file: str | Path, split: str, config: dict[str, Any], seed: int = 42):
        frame = pd.read_csv(split_file, dtype={"item_id": str})
        self.frame = frame.loc[frame["split"] == split].reset_index(drop=True)
        if self.frame.empty:
            raise ValueError(f"No rows for split={split}")
        self.split = split
        self.config = config
        self.seed = int(seed)
        self.epoch = 0
        self.training = split == "train"

    def __len__(self) -> int:
        return len(self.frame)

    def set_epoch(self, epoch: int) -> None:
        self.epoch = int(epoch)

    def __getitem__(self, index: int):
        import torch

        row = self.frame.iloc[index]
        path = Path(str(row["feature_path"]))
        array = np.load(path, allow_pickle=False).astype(np.float32)
        if array.ndim == 3:
            array = array[np.newaxis, ...]
        if array.ndim != 4 or array.shape[1:] != (1, 128, 281):
            raise ValueError(f"Unexpected feature shape {array.shape} for {path}")
        windows = torch.from_numpy(array)
        target = torch.tensor([row["y_arousal"], row["y_valence"]], dtype=torch.float32)

        if self.training:
            views = int(self.config["augmentation"]["views_per_item"])
            produced = []
            for view in range(views):
                generator = torch.Generator()
                generator.manual_seed(self.seed * 1_000_003 + self.epoch * 10_007 + index * 101 + view)
                selected = int(torch.randint(0, windows.shape[0], (), generator=generator).item())
                produced.append(augment_log_mel(windows[selected], self.config, generator))
            inputs = torch.stack(produced, dim=0)
        else:
            inputs = windows
        return {"item_id": str(row["item_id"]), "inputs": inputs, "targets": target}

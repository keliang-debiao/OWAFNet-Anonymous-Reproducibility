from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.nn import functional as F
from torch.utils.data import DataLoader

from .data import LogMelManifestDataset
from .metrics import multitask_metrics
from .reproducibility import dataloader_worker_init, environment_snapshot, seed_everything


def _loss(logits: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
    return F.binary_cross_entropy_with_logits(logits, targets, reduction="none").sum(dim=1).mean()


def _forward_views(model: nn.Module, inputs: torch.Tensor) -> torch.Tensor:
    if inputs.ndim != 5:
        raise ValueError(f"Expected [batch, views, channel, mel, frame], received {tuple(inputs.shape)}")
    batch, views, channels, mel, frames = inputs.shape
    logits = model(inputs.reshape(batch * views, channels, mel, frames))
    return logits.reshape(batch, views, 2)


def _make_loader(dataset, batch_size: int, shuffle: bool, workers: int, seed: int) -> DataLoader:
    generator = torch.Generator()
    generator.manual_seed(seed)
    return DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=workers,
        pin_memory=torch.cuda.is_available(),
        worker_init_fn=dataloader_worker_init,
        generator=generator,
        persistent_workers=workers > 0,
    )


def run_epoch(model: nn.Module, loader: DataLoader, device: torch.device, optimizer=None) -> tuple[float, list[str], np.ndarray, np.ndarray]:
    training = optimizer is not None
    model.train(training)
    losses: list[float] = []
    identifiers: list[str] = []
    labels: list[np.ndarray] = []
    probabilities: list[np.ndarray] = []
    for batch in loader:
        inputs = batch["inputs"].to(device=device, dtype=torch.float32, non_blocking=True)
        targets = batch["targets"].to(device=device, dtype=torch.float32, non_blocking=True)
        with torch.set_grad_enabled(training):
            view_logits = _forward_views(model, inputs)
            expanded_targets = targets[:, None, :].expand_as(view_logits).reshape(-1, 2)
            loss = _loss(view_logits.reshape(-1, 2), expanded_targets)
            if training:
                optimizer.zero_grad(set_to_none=True)
                loss.backward()
                optimizer.step()
        item_logits = view_logits.mean(dim=1)
        losses.append(float(loss.detach().cpu()))
        identifiers.extend(str(value) for value in batch["item_id"])
        labels.append(targets.detach().cpu().numpy())
        probabilities.append(torch.sigmoid(item_logits).detach().cpu().numpy())
    return float(np.mean(losses)), identifiers, np.concatenate(labels), np.concatenate(probabilities)


def fit(model: nn.Module, config: dict[str, Any], split_file: str | Path, seed: int, output_dir: str | Path) -> dict[str, Any]:
    seed_everything(seed)
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = model.to(device)

    train_dataset = LogMelManifestDataset(split_file, "train", config, seed)
    validation_dataset = LogMelManifestDataset(split_file, "validation", config, seed)
    test_dataset = LogMelManifestDataset(split_file, "test", config, seed)
    batch_size = int(config["optimizer"]["batch_size"])
    workers = int(config["training"].get("num_workers", 4))
    train_loader = _make_loader(train_dataset, batch_size, True, workers, seed)
    validation_loader = _make_loader(validation_dataset, batch_size, False, workers, seed + 1)
    test_loader = _make_loader(test_dataset, batch_size, False, workers, seed + 2)

    optimizer = torch.optim.Adam(
        [parameter for parameter in model.parameters() if parameter.requires_grad],
        lr=float(config["optimizer"]["learning_rate"]),
        weight_decay=float(config["optimizer"]["weight_decay"]),
        betas=(float(config["training"]["beta1"]), float(config["training"]["beta2"])),
        eps=float(config["training"]["optimizer_epsilon"]),
    )
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer,
        mode="max",
        factor=float(config["training"]["scheduler_factor"]),
        patience=int(config["training"]["scheduler_patience"]),
        min_lr=float(config["training"]["minimum_learning_rate"]),
    )
    maximum_epochs = int(config["training"]["max_epochs"])
    patience = int(config["training"]["early_stopping_patience"])
    delta = float(config["training"]["improvement_delta"])
    threshold = float(config["training"]["probability_threshold"])
    bins = int(config["training"]["ece_bins"])

    best_score = -float("inf")
    best_epoch = 0
    early_stop_reference = -float("inf")
    stale_epochs = 0
    checkpoint = output / "best_checkpoint.pt"
    log_path = output / "epochs.jsonl"
    with log_path.open("w", encoding="utf-8") as log_handle:
        for epoch in range(1, maximum_epochs + 1):
            train_dataset.set_epoch(epoch)
            train_loss, _, train_labels, train_probabilities = run_epoch(model, train_loader, device, optimizer)
            validation_loss, _, validation_labels, validation_probabilities = run_epoch(model, validation_loader, device)
            train_metrics = multitask_metrics(train_labels, train_probabilities, threshold, bins)
            validation_metrics = multitask_metrics(validation_labels, validation_probabilities, threshold, bins)
            score = float(validation_metrics["average_f1"])
            scheduler.step(score)
            rounded_score = round(score, 8)
            improved = rounded_score > round(best_score, 8)
            if improved:
                best_score = score
                best_epoch = epoch
                torch.save({"model_state": model.state_dict(), "epoch": epoch, "validation_average_f1": score, "seed": seed}, checkpoint)
            if score > early_stop_reference + delta:
                early_stop_reference = score
                stale_epochs = 0
            else:
                stale_epochs += 1
            record = {
                "epoch": epoch,
                "train_loss": train_loss,
                "validation_loss": validation_loss,
                "train_average_f1": train_metrics["average_f1"],
                "validation_average_f1": score,
                "learning_rate": optimizer.param_groups[0]["lr"],
                "improved": improved,
            }
            log_handle.write(json.dumps(record, sort_keys=True) + "\n")
            log_handle.flush()
            if stale_epochs >= patience:
                break

    state = torch.load(checkpoint, map_location=device)
    model.load_state_dict(state["model_state"])
    test_loss, item_ids, test_labels, test_probabilities = run_epoch(model, test_loader, device)
    test_metrics = multitask_metrics(test_labels, test_probabilities, threshold, bins)
    prediction_frame = pd.DataFrame(
        {
            "item_id": item_ids,
            "y_arousal": test_labels[:, 0].astype(int),
            "y_valence": test_labels[:, 1].astype(int),
            "p_arousal": test_probabilities[:, 0],
            "p_valence": test_probabilities[:, 1],
        }
    )
    prediction_frame["pred_arousal"] = (prediction_frame["p_arousal"] > threshold).astype(int)
    prediction_frame["pred_valence"] = (prediction_frame["p_valence"] > threshold).astype(int)
    prediction_frame.to_csv(output / "test_predictions.csv", index=False)
    summary = {
        "seed": seed,
        "device": str(device),
        "best_epoch": best_epoch,
        "best_validation_average_f1": best_score,
        "test_loss": test_loss,
        "test_metrics": test_metrics,
        "environment": environment_snapshot(),
    }
    with (output / "summary.json").open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, indent=2, sort_keys=True)
    return summary

from __future__ import annotations

from typing import Any

import numpy as np
from sklearn.metrics import average_precision_score, confusion_matrix, roc_auc_score


TASKS = ("arousal", "valence")


def binary_class_f1(y_true: np.ndarray, y_pred: np.ndarray, label: int) -> float:
    y_true = np.asarray(y_true, dtype=int)
    y_pred = np.asarray(y_pred, dtype=int)
    tp = int(np.sum((y_true == label) & (y_pred == label)))
    fp = int(np.sum((y_true != label) & (y_pred == label)))
    fn = int(np.sum((y_true == label) & (y_pred != label)))
    denominator = 2 * tp + fp + fn
    return 0.0 if denominator == 0 else (2.0 * tp) / denominator


def support_weighted_f1(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    y_true = np.asarray(y_true, dtype=int)
    y_pred = np.asarray(y_pred, dtype=int)
    if y_true.shape != y_pred.shape:
        raise ValueError("y_true and y_pred must have identical shapes")
    if y_true.ndim != 1:
        raise ValueError("support_weighted_f1 expects one-dimensional arrays")
    total = y_true.size
    return sum(np.sum(y_true == label) / total * binary_class_f1(y_true, y_pred, label) for label in (0, 1))


def expected_calibration_error(y_true: np.ndarray, probability: np.ndarray, bins: int = 15) -> float:
    y_true = np.asarray(y_true, dtype=float)
    probability = np.asarray(probability, dtype=float)
    edges = np.linspace(0.0, 1.0, bins + 1)
    indices = np.minimum(np.digitize(probability, edges[1:-1], right=False), bins - 1)
    total = y_true.size
    value = 0.0
    for index in range(bins):
        member = indices == index
        if not np.any(member):
            continue
        value += np.sum(member) / total * abs(float(np.mean(probability[member])) - float(np.mean(y_true[member])))
    return float(value)


def brier_score(y_true: np.ndarray, probability: np.ndarray) -> float:
    return float(np.mean((np.asarray(probability, dtype=float) - np.asarray(y_true, dtype=float)) ** 2))


def task_metrics(y_true: np.ndarray, probability: np.ndarray, threshold: float = 0.5, ece_bins: int = 15) -> dict[str, Any]:
    y_true = np.asarray(y_true, dtype=int)
    probability = np.asarray(probability, dtype=float)
    prediction = (probability > threshold).astype(int)
    matrix = confusion_matrix(y_true, prediction, labels=[0, 1])
    result: dict[str, Any] = {
        "support_weighted_f1": support_weighted_f1(y_true, prediction),
        "class_f1": {"low": binary_class_f1(y_true, prediction, 0), "high": binary_class_f1(y_true, prediction, 1)},
        "brier": brier_score(y_true, probability),
        "ece": expected_calibration_error(y_true, probability, bins=ece_bins),
        "confusion": matrix.tolist(),
        "support": {"low": int(np.sum(y_true == 0)), "high": int(np.sum(y_true == 1))},
    }
    if np.unique(y_true).size == 2:
        result["pr_auc"] = float(average_precision_score(y_true, probability))
        result["roc_auc"] = float(roc_auc_score(y_true, probability))
    else:
        result["pr_auc"] = None
        result["roc_auc"] = None
    return result


def multitask_metrics(labels: np.ndarray, probabilities: np.ndarray, threshold: float = 0.5, ece_bins: int = 15) -> dict[str, Any]:
    labels = np.asarray(labels)
    probabilities = np.asarray(probabilities)
    if labels.shape != probabilities.shape or labels.ndim != 2 or labels.shape[1] != 2:
        raise ValueError("Expected labels and probabilities with shape [N, 2]")
    tasks = {
        name: task_metrics(labels[:, index], probabilities[:, index], threshold=threshold, ece_bins=ece_bins)
        for index, name in enumerate(TASKS)
    }
    tasks["average_f1"] = float(np.mean([tasks[name]["support_weighted_f1"] for name in TASKS]))
    return tasks

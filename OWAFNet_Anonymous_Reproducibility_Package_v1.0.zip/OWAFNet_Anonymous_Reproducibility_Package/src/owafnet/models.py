from __future__ import annotations

from typing import Any

import torch
from torch import nn
from torch.nn import functional as F


def _xavier_attention_modules(module: nn.Module) -> None:
    for child in module.modules():
        if isinstance(child, nn.MultiheadAttention):
            nn.init.xavier_uniform_(child.in_proj_weight)
            if child.in_proj_bias is not None:
                nn.init.zeros_(child.in_proj_bias)
            nn.init.xavier_uniform_(child.out_proj.weight)
            if child.out_proj.bias is not None:
                nn.init.zeros_(child.out_proj.bias)


class ConvBlock(nn.Sequential):
    def __init__(self, input_channels: int, output_channels: int):
        super().__init__(
            nn.Conv2d(input_channels, output_channels, kernel_size=3, stride=1, padding=1, bias=True),
            nn.BatchNorm2d(output_channels),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2),
        )


class WindowAttention2d(nn.Module):
    def __init__(self, channels: int = 64, window_size: int = 4, heads: int = 4, dropout: float = 0.2):
        super().__init__()
        if channels % heads:
            raise ValueError("channels must be divisible by heads")
        self.channels = channels
        self.window_size = window_size
        self.attention = nn.MultiheadAttention(channels, heads, dropout=dropout, batch_first=True)

    def _partition(self, tensor: torch.Tensor) -> torch.Tensor:
        batch, channels, height, width = tensor.shape
        size = self.window_size
        return (
            tensor.view(batch, channels, height // size, size, width // size, size)
            .permute(0, 2, 4, 3, 5, 1)
            .contiguous()
            .view(-1, size * size, channels)
        )

    def forward(self, x: torch.Tensor, return_attention_mass: bool = False):
        batch, channels, height, width = x.shape
        size = self.window_size
        pad_height = (size - height % size) % size
        pad_width = (size - width % size) % size
        padded = F.pad(x, (0, pad_width, 0, pad_height))
        padded_height, padded_width = padded.shape[-2:]
        windows = self._partition(padded)

        valid = torch.ones((batch, 1, height, width), dtype=torch.bool, device=x.device)
        valid = F.pad(valid, (0, pad_width, 0, pad_height), value=False)
        valid_windows = self._partition(valid.float()).squeeze(-1).bool()
        output, weights = self.attention(
            windows,
            windows,
            windows,
            key_padding_mask=~valid_windows,
            need_weights=return_attention_mass,
            average_attn_weights=False,
        )
        output = output + windows
        output = (
            output.view(batch, padded_height // size, padded_width // size, size, size, channels)
            .permute(0, 5, 1, 3, 2, 4)
            .contiguous()
            .view(batch, channels, padded_height, padded_width)
        )
        output = output[:, :, :height, :width]
        if not return_attention_mass:
            return output

        key_mass = weights.mean(dim=1).mean(dim=1)
        key_mass = key_mass * valid_windows.float()
        key_mass = key_mass / key_mass.sum(dim=1, keepdim=True).clamp_min(1.0e-12)
        mass = (
            key_mass.view(batch, padded_height // size, padded_width // size, size, size)
            .permute(0, 1, 3, 2, 4)
            .contiguous()
            .view(batch, padded_height, padded_width)
        )[:, :height, :width]
        mass = mass / mass.sum(dim=(1, 2), keepdim=True).clamp_min(1.0e-12)
        return output, mass


class FullAttention2d(nn.Module):
    def __init__(self, channels: int = 64, heads: int = 4, dropout: float = 0.2):
        super().__init__()
        self.attention = nn.MultiheadAttention(channels, heads, dropout=dropout, batch_first=True)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        batch, channels, height, width = x.shape
        tokens = x.flatten(2).transpose(1, 2)
        output, _ = self.attention(tokens, tokens, tokens, need_weights=False)
        return (output + tokens).transpose(1, 2).view(batch, channels, height, width)


class DoubleAttention2d(nn.Module):
    """Compact A2-style gather-and-distribute operator with shape preservation."""

    def __init__(self, channels: int = 64):
        super().__init__()
        reduced = channels // 2
        self.values = nn.Conv2d(channels, reduced, 1)
        self.gather = nn.Conv2d(channels, reduced, 1)
        self.distribute = nn.Conv2d(channels, reduced, 1)
        self.output = nn.Conv2d(reduced, channels, 1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        batch, _, height, width = x.shape
        values = self.values(x).flatten(2)
        gather = torch.softmax(self.gather(x).flatten(2), dim=-1)
        global_descriptors = torch.bmm(values, gather.transpose(1, 2))
        distribute = torch.softmax(self.distribute(x).flatten(2), dim=1)
        output = torch.bmm(global_descriptors, distribute).view(batch, -1, height, width)
        return x + self.output(output)


class UFOAttention2d(nn.Module):
    """L2-normalized linear attention used as a compact contextual substitute."""

    def __init__(self, channels: int = 64):
        super().__init__()
        self.query = nn.Linear(channels, channels)
        self.key = nn.Linear(channels, channels)
        self.value = nn.Linear(channels, channels)
        self.output = nn.Linear(channels, channels)
        self.scale = nn.Parameter(torch.ones(channels))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        batch, channels, height, width = x.shape
        tokens = x.flatten(2).transpose(1, 2)
        query = F.normalize(self.query(tokens), dim=-1)
        key = F.normalize(self.key(tokens), dim=1)
        value = self.value(tokens)
        context = torch.bmm(key.transpose(1, 2), value)
        output = torch.bmm(query, context) * self.scale
        output = self.output(output)
        return (output + tokens).transpose(1, 2).view(batch, channels, height, width)


class SEBlock(nn.Module):
    def __init__(self, channels: int = 64, reduction: int = 16):
        super().__init__()
        hidden = channels // reduction
        self.fc1 = nn.Linear(channels, hidden)
        self.fc2 = nn.Linear(hidden, channels)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        summary = x.mean(dim=(2, 3))
        scale = torch.sigmoid(self.fc2(F.relu(self.fc1(summary))))
        return x * scale[:, :, None, None]


class CBAMBlock(nn.Module):
    def __init__(self, channels: int = 64, reduction: int = 16):
        super().__init__()
        hidden = channels // reduction
        self.channel = nn.Sequential(nn.Linear(channels, hidden), nn.ReLU(), nn.Linear(hidden, channels))
        self.spatial = nn.Conv2d(2, 1, kernel_size=7, padding=3)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        average = x.mean(dim=(2, 3))
        maximum = x.amax(dim=(2, 3))
        channel_scale = torch.sigmoid(self.channel(average) + self.channel(maximum))
        x = x * channel_scale[:, :, None, None]
        spatial = torch.cat([x.mean(dim=1, keepdim=True), x.amax(dim=1, keepdim=True)], dim=1)
        return x * torch.sigmoid(self.spatial(spatial))


class DynamicCBAMBlock(nn.Module):
    """Content-conditioned two-expert CBAM operationalization for the substitution run."""

    def __init__(self, channels: int = 64, reduction: int = 16):
        super().__init__()
        self.experts = nn.ModuleList([CBAMBlock(channels, reduction), CBAMBlock(channels, reduction)])
        self.router = nn.Linear(channels, 2)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        weights = torch.softmax(self.router(x.mean(dim=(2, 3))), dim=1)
        outputs = torch.stack([expert(x) for expert in self.experts], dim=1)
        return (outputs * weights[:, :, None, None, None]).sum(dim=1)


class LearnedGateFusion(nn.Module):
    def __init__(self, dimension: int = 64):
        super().__init__()
        self.gate = nn.Linear(2 * dimension, dimension)

    def forward(self, global_descriptor: torch.Tensor, local_descriptor: torch.Tensor) -> torch.Tensor:
        alpha = torch.sigmoid(self.gate(torch.cat([global_descriptor, local_descriptor], dim=1)))
        return alpha * global_descriptor + (1.0 - alpha) * local_descriptor


class OWAFNet(nn.Module):
    def __init__(self, config: dict[str, Any]):
        super().__init__()
        channels = list(config.get("convolution_channels", [32, 64, 64]))
        self.frontend = nn.Sequential(
            ConvBlock(int(config.get("input_channels", 1)), channels[0]),
            ConvBlock(channels[0], channels[1]),
            ConvBlock(channels[1], channels[2]),
        )
        final_channels = channels[-1]
        context = str(config.get("context", "window"))
        if context == "window":
            self.context = WindowAttention2d(
                final_channels,
                int(config.get("window_size", 4)),
                int(config.get("attention_heads", 4)),
                float(config.get("attention_dropout", 0.2)),
            )
        elif context == "full_attention":
            self.context = FullAttention2d(final_channels, int(config.get("attention_heads", 4)), float(config.get("attention_dropout", 0.2)))
        elif context == "double_attention":
            self.context = DoubleAttention2d(final_channels)
        elif context == "ufo_attention":
            self.context = UFOAttention2d(final_channels)
        elif context == "none":
            self.context = nn.Identity()
        else:
            raise ValueError(f"Unknown context operator: {context}")

        recalibration = str(config.get("recalibration", "se"))
        reduction = int(config.get("se_reduction", 16))
        if recalibration == "se":
            self.recalibration = SEBlock(final_channels, reduction)
        elif recalibration == "cbam":
            self.recalibration = CBAMBlock(final_channels, reduction)
        elif recalibration == "dynamic_cbam":
            self.recalibration = DynamicCBAMBlock(final_channels, reduction)
        elif recalibration == "none":
            self.recalibration = nn.Identity()
        else:
            raise ValueError(f"Unknown recalibration operator: {recalibration}")

        descriptor_dimension = int(config.get("descriptor_dimension", 64))
        grids = list(config.get("pyramid_grids", [4, 2, 1]))
        local_channels = int(config.get("local_channels", final_channels))
        self.local_projection = nn.Conv2d(final_channels, local_channels, kernel_size=1, bias=True)
        self.pyramid_grids = grids
        self.local_fc = nn.Linear(local_channels * sum(grid * grid for grid in grids), descriptor_dimension)
        if final_channels != descriptor_dimension:
            self.global_fc = nn.Linear(final_channels, descriptor_dimension)
        else:
            self.global_fc = nn.Identity()

        fusion = str(config.get("fusion", "orthogonal"))
        self.fusion_name = fusion
        if fusion in {"concatenation", "orthogonal"}:
            classifier_input = 2 * descriptor_dimension
            self.fusion = None
        elif fusion == "addition":
            classifier_input = descriptor_dimension
            self.fusion = None
        elif fusion == "learned_gate":
            classifier_input = descriptor_dimension
            self.fusion = LearnedGateFusion(descriptor_dimension)
        elif fusion == "global_only":
            classifier_input = descriptor_dimension
            self.fusion = None
        else:
            raise ValueError(f"Unknown fusion: {fusion}")

        hidden = int(config.get("classifier_hidden", 128))
        dropout = float(config.get("dropout", 0.3))
        self.classifier = nn.Sequential(nn.Linear(classifier_input, hidden), nn.ReLU(), nn.Dropout(dropout), nn.Linear(hidden, 2))
        self.norm_epsilon = float(config.get("norm_epsilon", 1.0e-8))
        self.apply(self._initialize)
        self._initialize_attention()

    @staticmethod
    def _initialize(module: nn.Module) -> None:
        if isinstance(module, (nn.Conv2d, nn.Linear)):
            nn.init.kaiming_normal_(module.weight, nonlinearity="relu")
            if module.bias is not None:
                nn.init.zeros_(module.bias)
        elif isinstance(module, nn.BatchNorm2d):
            nn.init.ones_(module.weight)
            nn.init.zeros_(module.bias)

    def _initialize_attention(self) -> None:
        _xavier_attention_modules(self)

    def descriptors(self, x: torch.Tensor, return_attention_mass: bool = False):
        feature = self.frontend(x)
        attention_mass = None
        if return_attention_mass and isinstance(self.context, WindowAttention2d):
            feature, attention_mass = self.context(feature, return_attention_mass=True)
        else:
            feature = self.context(feature)
        feature = self.recalibration(feature)
        global_descriptor = self.global_fc(feature.mean(dim=(2, 3)))
        local_map = self.local_projection(feature)
        pooled = [F.adaptive_avg_pool2d(local_map, (grid, grid)).flatten(1) for grid in self.pyramid_grids]
        local_descriptor = self.local_fc(torch.cat(pooled, dim=1))
        return global_descriptor, local_descriptor, attention_mass

    def forward(self, x: torch.Tensor, return_descriptors: bool = False, return_attention_mass: bool = False):
        global_descriptor, local_descriptor, attention_mass = self.descriptors(x, return_attention_mass=return_attention_mass)
        if self.fusion_name == "orthogonal":
            direction = global_descriptor / (global_descriptor.norm(dim=1, keepdim=True) + self.norm_epsilon)
            projection = (local_descriptor * direction).sum(dim=1, keepdim=True) * direction
            residual = local_descriptor - projection
            fused = torch.cat([global_descriptor, residual], dim=1)
        elif self.fusion_name == "concatenation":
            residual = local_descriptor
            fused = torch.cat([global_descriptor, local_descriptor], dim=1)
        elif self.fusion_name == "addition":
            residual = local_descriptor
            fused = global_descriptor + local_descriptor
        elif self.fusion_name == "learned_gate":
            residual = local_descriptor
            fused = self.fusion(global_descriptor, local_descriptor)
        else:
            residual = local_descriptor
            fused = global_descriptor
        logits = self.classifier(fused)
        if return_descriptors or return_attention_mass:
            return {
                "logits": logits,
                "global_descriptor": global_descriptor,
                "local_descriptor": local_descriptor,
                "residual_descriptor": residual,
                "attention_mass": attention_mass,
            }
        return logits


class CNNBaseline(nn.Module):
    def __init__(self, config: dict[str, Any]):
        super().__init__()
        channels = list(config.get("channels", [32, 64, 128]))
        self.encoder = nn.Sequential(ConvBlock(1, channels[0]), ConvBlock(channels[0], channels[1]), ConvBlock(channels[1], channels[2]))
        pool = int(config.get("adaptive_pool", 4))
        hidden = int(config.get("classifier_hidden", 208))
        self.classifier = nn.Sequential(
            nn.AdaptiveAvgPool2d((pool, pool)),
            nn.Flatten(),
            nn.Linear(channels[-1] * pool * pool, hidden),
            nn.ReLU(),
            nn.Dropout(float(config.get("dropout", 0.3))),
            nn.Linear(hidden, 2),
        )
        self.apply(OWAFNet._initialize)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.classifier(self.encoder(x))


class BiLSTMBaseline(nn.Module):
    def __init__(self, config: dict[str, Any]):
        super().__init__()
        hidden = int(config.get("hidden_size", 128))
        layers = int(config.get("layers", 2))
        self.lstm = nn.LSTM(
            input_size=int(config.get("input_size", 128)),
            hidden_size=hidden,
            num_layers=layers,
            batch_first=True,
            bidirectional=bool(config.get("bidirectional", True)),
            dropout=float(config.get("dropout", 0.3)) if layers > 1 else 0.0,
        )
        output_size = hidden * (2 if bool(config.get("bidirectional", True)) else 1)
        head = int(config.get("classifier_hidden", 352))
        self.classifier = nn.Sequential(
            nn.Linear(output_size, head), nn.ReLU(), nn.Dropout(float(config.get("dropout", 0.3))), nn.Linear(head, 2)
        )
        self.classifier.apply(OWAFNet._initialize)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        sequence = x.squeeze(1).transpose(1, 2)
        encoded, _ = self.lstm(sequence)
        return self.classifier(encoded.mean(dim=1))


class TransformerBaseline(nn.Module):
    def __init__(self, config: dict[str, Any]):
        super().__init__()
        embedding = int(config.get("embedding_size", 256))
        maximum_steps = int(config.get("maximum_steps", 281))
        dropout = float(config.get("dropout", 0.2))
        self.input_projection = nn.Linear(int(config.get("input_size", 128)), embedding)
        self.position = nn.Parameter(torch.zeros(1, maximum_steps, embedding))
        layer = nn.TransformerEncoderLayer(
            d_model=embedding,
            nhead=int(config.get("heads", 4)),
            dim_feedforward=int(config.get("feedforward_size", 576)),
            dropout=dropout,
            activation="relu",
            batch_first=True,
            norm_first=False,
        )
        self.encoder = nn.TransformerEncoder(layer, num_layers=int(config.get("layers", 4)), enable_nested_tensor=False)
        head = int(config.get("classifier_hidden", 128))
        self.classifier = nn.Sequential(nn.Linear(embedding, head), nn.ReLU(), nn.Dropout(dropout), nn.Linear(head, 2))
        nn.init.normal_(self.position, std=0.02)
        self.input_projection.apply(OWAFNet._initialize)
        self.encoder.apply(OWAFNet._initialize)
        self.classifier.apply(OWAFNet._initialize)
        _xavier_attention_modules(self.encoder)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        sequence = x.squeeze(1).transpose(1, 2)
        embedded = self.input_projection(sequence) + self.position[:, : sequence.shape[1]]
        return self.classifier(self.encoder(embedded).mean(dim=1))


class ResidualBlock(nn.Module):
    expansion = 1

    def __init__(self, input_channels: int, channels: int, stride: int = 1):
        super().__init__()
        self.conv1 = nn.Conv2d(input_channels, channels, 3, stride=stride, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(channels)
        self.conv2 = nn.Conv2d(channels, channels, 3, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(channels)
        self.downsample = None
        if stride != 1 or input_channels != channels:
            self.downsample = nn.Sequential(nn.Conv2d(input_channels, channels, 1, stride=stride, bias=False), nn.BatchNorm2d(channels))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        identity = x if self.downsample is None else self.downsample(x)
        output = F.relu(self.bn1(self.conv1(x)), inplace=True)
        output = self.bn2(self.conv2(output))
        return F.relu(output + identity, inplace=True)


class ResNet18Baseline(nn.Module):
    def __init__(self, config: dict[str, Any]):
        super().__init__()
        self.current_channels = 64
        self.stem = nn.Sequential(
            nn.Conv2d(int(config.get("input_channels", 1)), 64, 7, stride=2, padding=3, bias=False),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(3, stride=2, padding=1),
        )
        blocks = list(config.get("layers", [2, 2, 2, 2]))
        self.stages = nn.Sequential(
            self._make_stage(64, blocks[0], 1),
            self._make_stage(128, blocks[1], 2),
            self._make_stage(256, blocks[2], 2),
            self._make_stage(512, blocks[3], 2),
        )
        hidden = int(config.get("classifier_hidden", 864))
        dropout = float(config.get("dropout", 0.3))
        self.classifier = nn.Sequential(nn.Linear(512, hidden), nn.ReLU(), nn.Dropout(dropout), nn.Linear(hidden, 2))
        self.apply(OWAFNet._initialize)

    def _make_stage(self, channels: int, blocks: int, stride: int) -> nn.Sequential:
        layers = [ResidualBlock(self.current_channels, channels, stride)]
        self.current_channels = channels
        layers.extend(ResidualBlock(channels, channels) for _ in range(1, blocks))
        return nn.Sequential(*layers)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        feature = self.stages(self.stem(x))
        return self.classifier(F.adaptive_avg_pool2d(feature, 1).flatten(1))


def build_model(config: dict[str, Any]) -> nn.Module:
    model_config = config["model"] if "model" in config else config
    name = str(model_config["name"]).lower()
    registry = {
        "owafnet": OWAFNet,
        "cnn": CNNBaseline,
        "bilstm": BiLSTMBaseline,
        "transformer": TransformerBaseline,
        "resnet18": ResNet18Baseline,
    }
    if name not in registry:
        raise ValueError(f"Unknown model: {name}")
    return registry[name](model_config)


def count_trainable_parameters(model: nn.Module) -> int:
    return sum(parameter.numel() for parameter in model.parameters() if parameter.requires_grad)

from __future__ import annotations

import torch
from torch import nn


class WaveformEncoderClassifier(nn.Module):
    def __init__(self, checkpoint: str, freeze_encoder: bool):
        super().__init__()
        from transformers import AutoModel

        self.encoder = AutoModel.from_pretrained(checkpoint)
        hidden = int(self.encoder.config.hidden_size)
        self.classifier = nn.Linear(hidden, 2)
        if freeze_encoder:
            for parameter in self.encoder.parameters():
                parameter.requires_grad = False

    def forward(self, input_values: torch.Tensor, attention_mask: torch.Tensor | None = None) -> torch.Tensor:
        output = self.encoder(input_values=input_values, attention_mask=attention_mask).last_hidden_state
        if attention_mask is None:
            pooled = output.mean(dim=1)
        else:
            feature_mask = self.encoder._get_feature_vector_attention_mask(output.shape[1], attention_mask)
            weights = feature_mask.unsqueeze(-1).to(output.dtype)
            pooled = (output * weights).sum(dim=1) / weights.sum(dim=1).clamp_min(1.0)
        return self.classifier(pooled)


class ASTEncoderClassifier(nn.Module):
    def __init__(self, checkpoint: str, freeze_encoder: bool):
        super().__init__()
        from transformers import ASTModel

        self.encoder = ASTModel.from_pretrained(checkpoint)
        hidden = int(self.encoder.config.hidden_size)
        self.classifier = nn.Linear(hidden, 2)
        if freeze_encoder:
            for parameter in self.encoder.parameters():
                parameter.requires_grad = False

    def forward(self, input_values: torch.Tensor) -> torch.Tensor:
        output = self.encoder(input_values=input_values).last_hidden_state
        return self.classifier(output[:, 0])


def build_pretrained(name: str, checkpoint: str, freeze_encoder: bool) -> nn.Module:
    if name.lower() in {"wav2vec2", "hubert"}:
        return WaveformEncoderClassifier(checkpoint, freeze_encoder)
    if name.lower() == "ast":
        return ASTEncoderClassifier(checkpoint, freeze_encoder)
    raise ValueError(f"Unsupported pretrained encoder: {name}")

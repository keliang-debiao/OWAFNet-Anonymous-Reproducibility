# Reference Values

`expected_results.json` is a structured transcription of the manuscript tables. It is a target for independent reruns, not evidence of a fresh execution.

`reference_predictions_seed42.csv` is a synthetic metric fixture. Its labels and probabilities are constructed to reproduce the reported PMEmo seed-42 confusion counts and rounded calibration values. It is marked `reference_fixture` in every row and must not be submitted as an empirical prediction file.

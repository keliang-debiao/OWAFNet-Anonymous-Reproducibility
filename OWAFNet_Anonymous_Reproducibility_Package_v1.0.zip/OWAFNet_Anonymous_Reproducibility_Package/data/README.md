# Data Preparation

This repository does not redistribute audio.

## PMEmo

Official source: <https://github.com/HuiZhangDB/PMEmo>

Use the 2018 release, static whole-clip annotations, and chorus audio. Build `data/manifests/pmemo.csv` with exactly 794 rows and these columns:

```text
item_id,audio_path,arousal,valence
```

`arousal` and `valence` must be the original static ratings on `[-1, 1]`. Paths may be relative to the repository root or absolute on the execution machine. The split file produced by `scripts/make_splits.py` adds normalized labels, binary targets, and the `split` column.

## DEAM

Official source: <https://cvml.unige.ch/databases/DEAM/>

Use all 1,802 released 45-second excerpts and the static whole-excerpt annotations. Build `data/manifests/deam.csv` with the same columns. Ratings must remain on the original `[1, 9]` scale until the split script normalizes them.

## Required audit

The split generator rejects duplicate identifiers, missing paths, nonfinite labels, out-of-range ratings, incorrect item counts, and incorrect partition sizes. It also writes a JSON audit file beside each split CSV. Keep the completed manifests private if their local paths contain identifying information; commit only path-portable manifests and frozen split assignments.
